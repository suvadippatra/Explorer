/**
 * OmniOS v2 - Server-Driven UI (SDUI) Client Engine
 * Lightweight rendering client: all application logic, window state,
 * and business rules execute strictly on the backend (Android Ktor / Node.js).
 */

window.OmniOS = window.OmniOS || {};

(function (OmniOS) {
  'use strict';

  class SDUIClient {
    constructor() {
      this.ws = null;
      this.connected = false;
      this.reconnectAttempts = 0;
      this.maxReconnectDelay = 5000;
      this.heartbeatTimer = null;
      this.lastRtt = 0;

      // Local authoritative cache of server state
      this.serverState = {
        windows: {},
        activeApp: null,
        dockApps: [],
        notifications: [],
        quickPanel: { wifi: true, bluetooth: true, volume: 80, brightness: 100, darkMode: true },
        adminConfig: {
          touchInputEnabled: true,
          allowedApps: ['files', 'video', 'music', 'pdf', 'notes', 'terminal', 'sysmon', 'settings'],
          settingsVisibility: { appearance: true, animation: true, sound: true, storage: true, host: true },
          theme: 'macos',
          animationDuration: 300
        },
        systemStats: { cpu: 12, ram: '2.4 / 8.0 GB', temp: 36, battery: 92 }
      };

      this.touchController = null;
      this.dom = {
        desktop: null,
        windowContainer: null,
        dock: null,
        topbar: null,
        quickPanel: null,
        notificationCenter: null,
        disconnectBarrier: null,
        rttBadge: null
      };

      this.windowDragState = null;
    }

    init() {
      this.cacheDom();
      this.detectEnvironment();
      this.initTouch();
      this.initEventListeners();
      this.updateTopbarLogo();
      this.applyBrightness(this.serverState.quickPanel.brightness || 100);
      this.applyDarkMode(this.serverState.quickPanel.darkMode !== false);
      this.connect();
    }

    detectEnvironment() {
      const params = new URLSearchParams(window.location.search);
      const isReceiver = params.get('mode') === 'receiver' ||
                         params.get('receiver') === 'true' ||
                         params.get('cast') === 'true' ||
                         window.AndroidReceiverBridge !== undefined ||
                         window.matchMedia('(display-mode: standalone)').matches;

      if (isReceiver) {
        document.body.classList.add('receiver-mode');
        console.log('[SDUI] Running in Receiver / Wireless Display mode. Fullscreen controls hidden.');
      }

      document.addEventListener('fullscreenchange', () => {
        document.body.classList.toggle('fullscreen-active', Boolean(document.fullscreenElement));
      });
    }

    updateTopbarLogo() {
      const trigger = document.getElementById('os-menu-trigger');
      if (trigger && OmniOS.icons && typeof OmniOS.icons.getSystemLogo === 'function') {
        const theme = this.serverState.adminConfig.theme || 'macos';
        trigger.innerHTML = OmniOS.icons.getSystemLogo(theme, 18);
      }
    }

    applyBrightness(val) {
      const b = Math.max(15, Math.min(100, val || 100));
      this.serverState.quickPanel.brightness = b;
      document.documentElement.style.setProperty('--display-brightness', b);
      if (this.dom.desktop) {
        this.dom.desktop.style.filter = `brightness(${b / 100})`;
      }
    }

    applyDarkMode(enabled) {
      const isDark = Boolean(enabled);
      this.serverState.quickPanel.darkMode = isDark;
      document.documentElement.setAttribute('data-mode', isDark ? 'dark' : 'light');
      document.body.classList.toggle('dark-mode', isDark);
      document.body.classList.toggle('light-mode', !isDark);
    }

    cacheDom() {
      this.dom.desktop = document.getElementById('desktop');
      this.dom.windowContainer = document.getElementById('window-container');
      this.dom.dock = document.getElementById('dock');
      this.dom.topbar = document.getElementById('topbar');
      this.dom.quickPanel = document.getElementById('quick-panel');
      this.dom.notificationCenter = document.getElementById('notification-center');
      this.dom.disconnectBarrier = document.getElementById('omnios-disconnect-barrier');
      this.dom.rttBadge = document.getElementById('rtt-status-badge');
    }

    initTouch() {
      if (OmniOS.TouchController) {
        this.touchController = new OmniOS.TouchController();
        this.touchController.init(document.getElementById('omnios-touch-plane'), (data) => {
          this.sendRaw(data);
        });
      }
    }

    initEventListeners() {
      // Global window drag & resize handling (rate-limited dispatch to server)
      window.addEventListener('pointermove', (e) => this.handleWindowPointerMove(e));
      window.addEventListener('pointerup', (e) => this.handleWindowPointerUp(e));

      // Clock tick in topbar
      this.startClock();

      // Quick panel toggle
      const qpTrigger = document.getElementById('quick-panel-trigger');
      if (qpTrigger) {
        qpTrigger.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleQuickPanel();
        });
      }

      // Notification center toggle
      const notifTrigger = document.getElementById('notif-center-trigger');
      if (notifTrigger) {
        notifTrigger.addEventListener('click', (e) => {
          e.stopPropagation();
          this.toggleNotificationCenter();
        });
      }

      // Close panels when clicking desktop
      if (this.dom.desktop) {
        this.dom.desktop.addEventListener('click', () => {
          this.closePopups();
        });
      }

      // Fullscreen toggle button
      const fsBtn = document.getElementById('topbar-fullscreen-btn');
      if (fsBtn) {
        fsBtn.addEventListener('click', () => {
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
          } else {
            document.exitFullscreen().catch(() => {});
          }
        });
      }
    }

    startClock() {
      const clockEl = document.getElementById('topbar-clock');
      const update = () => {
        if (!clockEl) return;
        const now = new Date();
        clockEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      };
      update();
      setInterval(update, 1000);
    }

    /* ==========================================================================
       WebSocket Connection & Reconnection Management
       ========================================================================== */

    connect() {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host || 'localhost:8080';
      const wsUrl = `${protocol}//${host}/ws/sdui`;

      this.showDisconnectBarrier(true, 'Connecting to OmniOS Host Server...');

      try {
        this.ws = new WebSocket(wsUrl);
        this.ws.binaryType = 'arraybuffer';

        this.ws.onopen = () => {
          console.log('[SDUI] Connected to host backend:', wsUrl);
          this.connected = true;
          this.reconnectAttempts = 0;
          this.showDisconnectBarrier(false);
          this.startHeartbeat();

          // Request authoritative full state sync
          this.send(OmniOSProtocol.OPCODES.SYNC_REQUEST, { clientTime: Date.now() });
        };

        this.ws.onmessage = (event) => {
          const msg = OmniOSProtocol.unpack(event.data);
          this.handleServerMessage(msg);
        };

        this.ws.onclose = (event) => {
          console.warn('[SDUI] Connection closed by host', event);
          this.handleDisconnect();
        };

        this.ws.onerror = (err) => {
          console.error('[SDUI] WebSocket error', err);
          this.handleDisconnect();
        };
      } catch (err) {
        console.error('[SDUI] Socket instantiation error', err);
        this.handleDisconnect();
      }
    }

    handleDisconnect() {
      this.connected = false;
      this.stopHeartbeat();
      this.showDisconnectBarrier(true, `Connection Lost. Reconnecting in ${(Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), this.maxReconnectDelay) / 1000).toFixed(1)}s...`);

      const delay = Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), this.maxReconnectDelay);
      this.reconnectAttempts++;

      setTimeout(() => {
        if (!this.connected) {
          console.log(`[SDUI] Attempting reconnect #${this.reconnectAttempts}`);
          this.connect();
        }
      }, delay);
    }

    showDisconnectBarrier(show, message = 'Connection Lost') {
      if (!this.dom.disconnectBarrier) return;
      const statusText = document.getElementById('disconnect-status-text');
      if (statusText) statusText.textContent = message;

      if (show) {
        this.dom.disconnectBarrier.classList.remove('hidden');
        document.body.classList.add('server-disconnected');
      } else {
        this.dom.disconnectBarrier.classList.add('hidden');
        document.body.classList.remove('server-disconnected');
      }
    }

    startHeartbeat() {
      this.stopHeartbeat();
      this.heartbeatTimer = setInterval(() => {
        if (this.connected && this.ws.readyState === WebSocket.OPEN) {
          this.send(OmniOSProtocol.OPCODES.HEARTBEAT, { ts: Date.now() });
        }
      }, 3000);
    }

    stopHeartbeat() {
      if (this.heartbeatTimer) {
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
      }
    }

    send(opcode, payload) {
      if (!this.connected || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      const json = OmniOSProtocol.packJson(opcode, payload);
      this.ws.send(json);
    }

    sendRaw(buffer) {
      if (!this.connected || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      this.ws.send(buffer);
    }

    /* ==========================================================================
       Message Dispatcher & Differential Patch Reconciler
       ========================================================================== */

    handleServerMessage(msg) {
      if (!msg) return;

      switch (msg.op) {
        case OmniOSProtocol.OPCODES.FULL_SYNC:
          this.applyFullSync(msg.state);
          break;

        case OmniOSProtocol.OPCODES.STATE_DELTA:
          this.applyStateDelta(msg.delta);
          break;

        case OmniOSProtocol.OPCODES.ADMIN_CONFIG:
          this.applyAdminConfig(msg.config);
          break;

        case OmniOSProtocol.OPCODES.HEARTBEAT_ACK:
          this.lastRtt = Date.now() - (msg.ts || Date.now());
          this.updateRttBadge();
          break;

        default:
          console.warn('[SDUI] Unhandled message opcode:', msg.op, msg);
      }
    }

    updateRttBadge() {
      if (!this.dom.rttBadge) return;
      const quality = this.lastRtt < 25 ? 'optimal' : this.lastRtt < 70 ? 'good' : 'fair';
      this.dom.rttBadge.innerHTML = `
        <span class="rtt-dot ${quality}"></span>
        <span>RTT: ${this.lastRtt}ms</span>
      `;
    }

    applyFullSync(state) {
      console.log('[SDUI] Authoritative full sync received:', state);
      this.serverState = { ...this.serverState, ...state };

      // Apply theme & animations
      if (state.adminConfig) {
        this.applyAdminConfig(state.adminConfig);
      }

      // Render all subsystems
      this.renderDock();
      this.renderWindows();
      this.renderNotifications();
      this.renderQuickPanel();
      this.renderDesktopShortcuts();
    }

    applyStateDelta(delta) {
      if (!Array.isArray(delta)) return;

      for (const patch of delta) {
        const { type, entity, id, data } = patch;

        if (entity === 'window') {
          if (type === 'add' || type === 'update') {
            this.serverState.windows[id] = { ...(this.serverState.windows[id] || {}), ...data };
            this.patchWindowDom(id, this.serverState.windows[id]);
          } else if (type === 'remove') {
            delete this.serverState.windows[id];
            this.removeWindowDom(id);
          }
        } else if (entity === 'notification') {
          if (type === 'add') {
            this.serverState.notifications.unshift(data);
            this.renderNotifications();
            this.showNotificationToast(data);
          } else if (type === 'remove') {
            this.serverState.notifications = this.serverState.notifications.filter(n => n.id !== id);
            this.renderNotifications();
          }
        } else if (entity === 'quickPanel') {
          this.serverState.quickPanel = { ...this.serverState.quickPanel, ...data };
          this.renderQuickPanel();
        } else if (entity === 'systemStats') {
          this.serverState.systemStats = { ...this.serverState.systemStats, ...data };
          this.updateSystemMonitorView();
        }
      }

      this.updateDockRunningIndicators();
    }

    applyAdminConfig(config) {
      this.serverState.adminConfig = { ...this.serverState.adminConfig, ...config };

      // Touch policy
      if (this.touchController) {
        this.touchController.setTouchEnabled(this.serverState.adminConfig.touchInputEnabled);
      }

      // Update custom icon overrides
      if (config.customIcons && typeof config.customIcons === 'object') {
        for (const [id, svg] of Object.entries(config.customIcons)) {
          if (OmniOS.icons && typeof OmniOS.icons.setCustomIcon === 'function') {
            OmniOS.icons.setCustomIcon(id, svg);
          }
        }
      }

      // Update theme
      if (this.serverState.adminConfig.theme) {
        document.body.setAttribute('data-theme', this.serverState.adminConfig.theme);
        this.updateTopbarLogo();
      }

      // Update animation speed
      if (this.serverState.adminConfig.animationDuration !== undefined) {
        document.documentElement.style.setProperty('--os-anim-duration', `${this.serverState.adminConfig.animationDuration}ms`);
      }

      // Update display brightness (software luminance filter for wireless displays)
      if (this.serverState.adminConfig.brightness !== undefined) {
        this.applyBrightness(this.serverState.adminConfig.brightness);
      }

      // Update dark mode
      if (this.serverState.adminConfig.darkMode !== undefined) {
        this.applyDarkMode(this.serverState.adminConfig.darkMode);
      }

      // Re-render dock & settings with filtered apps/cards
      this.renderDock();
      this.renderDesktopShortcuts();
      this.patchOpenSettingsWindow();
    }

    /* ==========================================================================
       Window Management & Differential DOM Patching
       ========================================================================== */

    renderWindows() {
      if (!this.dom.windowContainer) return;
      const currentWinIds = new Set(Object.keys(this.serverState.windows));

      // Remove DOM elements not in server state
      const existingEls = this.dom.windowContainer.querySelectorAll('.os-window');
      existingEls.forEach(el => {
        const winId = el.getAttribute('data-win-id');
        if (!currentWinIds.has(winId)) {
          el.remove();
        }
      });

      // Patch / create all windows
      for (const [winId, win] of Object.entries(this.serverState.windows)) {
        this.patchWindowDom(winId, win);
      }
    }

    patchWindowDom(winId, win) {
      if (!this.dom.windowContainer) return;
      let winEl = this.dom.windowContainer.querySelector(`[data-win-id="${winId}"]`);

      if (!winEl) {
        winEl = this.createWindowShell(winId, win);
        this.dom.windowContainer.appendChild(winEl);
      }

      // Apply geometry & state
      winEl.style.left = `${win.x}px`;
      winEl.style.top = `${win.y}px`;
      winEl.style.width = `${win.width}px`;
      winEl.style.height = `${win.height}px`;
      winEl.style.zIndex = win.zIndex || 10;

      // Minimized / Maximized classes
      winEl.classList.toggle('minimized', Boolean(win.isMinimized));
      winEl.classList.toggle('maximized', Boolean(win.isMaximized));
      winEl.classList.toggle('active', Boolean(win.isFocused));

      // Update title
      const titleText = winEl.querySelector('.window-title-text');
      if (titleText && win.title) titleText.textContent = win.title;

      // Render / update inner application content
      const bodyEl = winEl.querySelector('.window-content');
      if (bodyEl && (!bodyEl.hasChildNodes() || win.needsContentRefresh)) {
        this.renderAppContent(win.appId, winId, bodyEl, win.appData);
        win.needsContentRefresh = false;
      }
    }

    createWindowShell(winId, win) {
      const el = document.createElement('div');
      el.className = 'os-window glass-card';
      el.setAttribute('data-win-id', winId);
      el.setAttribute('data-app-id', win.appId);

      el.innerHTML = `
        <div class="window-titlebar">
          <div class="window-controls">
            <button class="win-btn win-close" title="Close"></button>
            <button class="win-btn win-min" title="Minimize"></button>
            <button class="win-btn win-max" title="Maximize"></button>
          </div>
          <div class="window-title">
            <span class="window-icon">${this.getAppIconSvg(win.appId, 16)}</span>
            <span class="window-title-text">${win.title || win.appId}</span>
          </div>
          <div class="window-actions-extra"></div>
        </div>
        <div class="window-content"></div>
        <div class="window-resize-handle"></div>
      `;

      // Window focus on click
      el.addEventListener('pointerdown', (e) => {
        e.stopPropagation();
        this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, {
          action: 'focus',
          winId: winId
        });
      });

      // Controls
      el.querySelector('.win-close').addEventListener('click', (e) => {
        e.stopPropagation();
        this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'close', winId });
      });
      el.querySelector('.win-min').addEventListener('click', (e) => {
        e.stopPropagation();
        this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'minimize', winId });
      });
      el.querySelector('.win-max').addEventListener('click', (e) => {
        e.stopPropagation();
        this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'maximize', winId });
      });

      // Titlebar drag initiation
      const titlebar = el.querySelector('.window-titlebar');
      titlebar.addEventListener('pointerdown', (e) => {
        if (e.target.closest('.win-btn')) return;
        e.preventDefault();
        this.startWindowDrag(e, winId, el, 'move');
      });

      // Resize handle initiation
      const resizeHandle = el.querySelector('.window-resize-handle');
      if (resizeHandle) {
        resizeHandle.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          e.stopPropagation();
          this.startWindowDrag(e, winId, el, 'resize');
        });
      }

      return el;
    }

    removeWindowDom(winId) {
      const el = this.dom.windowContainer?.querySelector(`[data-win-id="${winId}"]`);
      if (el) {
        el.classList.add('closing');
        setTimeout(() => el.remove(), 250);
      }
    }

    startWindowDrag(e, winId, winEl, mode) {
      const rect = winEl.getBoundingClientRect();
      this.windowDragState = {
        winId,
        winEl,
        mode,
        startX: e.clientX,
        startY: e.clientY,
        initialX: rect.left,
        initialY: rect.top,
        initialW: rect.width,
        initialH: rect.height,
        lastSent: 0
      };
      winEl.classList.add('dragging');
    }

    handleWindowPointerMove(e) {
      if (!this.windowDragState) return;
      const s = this.windowDragState;
      const dx = e.clientX - s.startX;
      const dy = e.clientY - s.startY;

      if (s.mode === 'move') {
        const newX = Math.max(0, s.initialX + dx);
        const newY = Math.max(30, s.initialY + dy);
        s.winEl.style.left = `${newX}px`;
        s.winEl.style.top = `${newY}px`;

        // Dispatch position update to host state engine (throttled)
        const now = Date.now();
        if (now - s.lastSent > 33) { // ~30 fps updates to server
          s.lastSent = now;
          this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, {
            action: 'move',
            winId: s.winId,
            x: newX,
            y: newY
          });
        }
      } else if (s.mode === 'resize') {
        const newW = Math.max(320, s.initialW + dx);
        const newH = Math.max(220, s.initialH + dy);
        s.winEl.style.width = `${newW}px`;
        s.winEl.style.height = `${newH}px`;

        const now = Date.now();
        if (now - s.lastSent > 33) {
          s.lastSent = now;
          this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, {
            action: 'resize',
            winId: s.winId,
            width: newW,
            height: newH
          });
        }
      }
    }

    handleWindowPointerUp(e) {
      if (!this.windowDragState) return;
      const s = this.windowDragState;
      s.winEl.classList.remove('dragging');

      // Final authoritative state dispatch
      const rect = s.winEl.getBoundingClientRect();
      this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, {
        action: s.mode === 'move' ? 'move' : 'resize',
        winId: s.winId,
        x: rect.left,
        y: rect.top,
        width: rect.width,
        height: rect.height
      });

      this.windowDragState = null;
    }

    /* ==========================================================================
       Application Component Renderer (SDUI Logic)
       ========================================================================== */

    renderAppContent(appId, winId, container, appData = {}) {
      container.innerHTML = '';

      switch (appId) {
        case 'files':
          this.renderFileManagerApp(winId, container, appData);
          break;
        case 'video':
          this.renderVideoPlayerApp(winId, container, appData);
          break;
        case 'music':
          this.renderAudioPlayerApp(winId, container, appData);
          break;
        case 'pdf':
          this.renderPdfViewerApp(winId, container, appData);
          break;
        case 'notes':
          this.renderTextEditorApp(winId, container, appData);
          break;
        case 'terminal':
          this.renderTerminalApp(winId, container, appData);
          break;
        case 'sysmon':
          this.renderSystemMonitorApp(winId, container, appData);
          break;
        case 'settings':
          this.renderSettingsApp(winId, container, appData);
          break;
        default:
          container.innerHTML = `<div class="p-6 text-center text-muted">Unknown application: ${appId}</div>`;
      }
    }

    // 1. File Manager (Host Sandboxed)
    renderFileManagerApp(winId, container, appData) {
      const files = appData.files || [
        { name: 'Documents', type: 'folder', size: '4 items' },
        { name: 'Media', type: 'folder', size: '12 items' },
        { name: 'welcome_v2.txt', type: 'file', ext: 'txt', size: '2.4 KB' },
        { name: 'presentation_sample.mp4', type: 'file', ext: 'mp4', size: '18.5 MB' },
        { name: 'ambient_theme.mp3', type: 'file', ext: 'mp3', size: '4.2 MB' },
        { name: 'system_architecture.pdf', type: 'file', ext: 'pdf', size: '1.1 MB' }
      ];

      const currentPath = appData.currentPath || '/sdcard/OmniOS/Sandbox';

      container.innerHTML = `
        <div class="file-manager-root">
          <div class="fm-toolbar">
            <button class="fm-btn fm-back">‹ Back</button>
            <div class="fm-path-bar">${currentPath}</div>
            <button class="fm-btn fm-refresh">↻ Refresh</button>
          </div>
          <div class="fm-grid">
            ${files.map(f => `
              <div class="fm-item" data-name="${f.name}" data-type="${f.type}" data-ext="${f.ext || ''}">
                <div class="fm-icon">${f.type === 'folder' ? '📁' : this.getFileTypeIcon(f.ext)}</div>
                <div class="fm-name">${f.name}</div>
                <div class="fm-size">${f.size}</div>
              </div>
            `).join('')}
          </div>
        </div>
      `;

      container.querySelectorAll('.fm-item').forEach(item => {
        item.addEventListener('dblclick', () => {
          const name = item.getAttribute('data-name');
          const ext = item.getAttribute('data-ext');
          this.send(OmniOSProtocol.OPCODES.APP_ACTION, {
            winId,
            appId: 'files',
            action: 'open_file',
            filename: name,
            ext: ext
          });
        });
      });
    }

    getFileTypeIcon(ext) {
      if (ext === 'mp4' || ext === 'mkv') return '🎬';
      if (ext === 'mp3' || ext === 'wav') return '🎵';
      if (ext === 'pdf') return '📄';
      if (ext === 'txt' || ext === 'md' || ext === 'json') return '📝';
      return '📄';
    }

    // 2. Video Player
    renderVideoPlayerApp(winId, container, appData) {
      const src = appData.videoSrc || '';
      container.innerHTML = `
        <div class="media-player-root video-theme">
          <div class="media-screen">
            ${src ? `<video src="${src}" controls autoplay class="media-video-element"></video>` : `
              <div class="empty-media-state">
                <div class="empty-icon">🎬</div>
                <div class="empty-title">OmniOS Hardware Video Streamer</div>
                <div class="empty-desc">Drop an MP4/MKV video or open via File Manager</div>
              </div>
            `}
          </div>
        </div>
      `;
    }

    // 3. Audio Player
    renderAudioPlayerApp(winId, container, appData) {
      const track = appData.currentTrack || { title: 'High-Res Audio Engine', artist: 'Host System' };
      container.innerHTML = `
        <div class="media-player-root audio-theme p-6">
          <div class="audio-disc-animation">
            <div class="vinyl-disc"></div>
          </div>
          <div class="audio-info text-center mt-4">
            <h3 class="text-lg font-bold">${track.title}</h3>
            <p class="text-sm text-muted">${track.artist}</p>
          </div>
          <div class="audio-controls mt-6 flex justify-center gap-4">
            <button class="os-btn">⏮</button>
            <button class="os-btn primary">▶ / ⏸</button>
            <button class="os-btn">⏭</button>
          </div>
        </div>
      `;
    }

    // 4. PDF Viewer
    renderPdfViewerApp(winId, container, appData) {
      container.innerHTML = `
        <div class="pdf-viewer-root p-4">
          <div class="pdf-toolbar mb-3 flex items-center justify-between">
            <span class="text-sm font-semibold">${appData.docName || 'System Architecture.pdf'}</span>
            <div class="pdf-zoom-btns flex gap-2">
              <button class="os-btn small">-</button>
              <span class="text-xs">100%</span>
              <button class="os-btn small">+</button>
            </div>
          </div>
          <div class="pdf-page-canvas glass-panel p-8 text-sm leading-relaxed">
            <h2 class="text-xl font-bold mb-4">OmniOS v2 Architecture Specification</h2>
            <p class="mb-3">This PDF document is served directly through the host device's isolated storage sandbox.</p>
            <p class="text-muted">Interactive zoom, vector pagination, and search are authoritative on backend.</p>
          </div>
        </div>
      `;
    }

    // 5. Text Editor
    renderTextEditorApp(winId, container, appData) {
      const content = appData.content || '# Welcome to OmniOS v2\n\n- Server-Authoritative SDUI\n- Low-Latency Touch Streaming\n- Host-Enforced Sandboxing\n';
      container.innerHTML = `
        <div class="editor-root flex flex-col h-full">
          <div class="editor-toolbar p-2 border-b flex gap-2">
            <button class="os-btn small editor-save">Save to Host</button>
          </div>
          <textarea class="editor-textarea flex-1 p-4 font-mono text-sm">${content}</textarea>
        </div>
      `;

      const saveBtn = container.querySelector('.editor-save');
      const textarea = container.querySelector('.editor-textarea');
      if (saveBtn && textarea) {
        saveBtn.addEventListener('click', () => {
          this.send(OmniOSProtocol.OPCODES.APP_ACTION, {
            winId,
            appId: 'notes',
            action: 'save',
            content: textarea.value
          });
        });
      }
    }

    // 6. Terminal
    renderTerminalApp(winId, container, appData) {
      container.innerHTML = `
        <div class="terminal-root font-mono p-4 bg-black text-green-400 h-full flex flex-col">
          <div class="terminal-output flex-1 overflow-y-auto mb-2 text-xs leading-5">
            <div>OmniOS v2 Server Terminal [Host: Android / Termux]</div>
            <div>Type 'help' for authoritative commands.</div>
          </div>
          <div class="terminal-input-line flex items-center gap-2">
            <span class="text-blue-400">host@omnios:~$</span>
            <input type="text" class="terminal-input flex-1 bg-transparent border-none text-green-400 outline-none text-xs font-mono" />
          </div>
        </div>
      `;

      const input = container.querySelector('.terminal-input');
      const output = container.querySelector('.terminal-output');

      input?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const cmd = input.value.trim();
          input.value = '';
          if (!cmd) return;

          const line = document.createElement('div');
          line.textContent = `host@omnios:~$ ${cmd}`;
          output.appendChild(line);

          // Local echo / server command dispatch
          this.send(OmniOSProtocol.OPCODES.APP_ACTION, {
            winId,
            appId: 'terminal',
            action: 'exec',
            cmd
          });

          // Simulate immediate response
          const res = document.createElement('div');
          res.className = 'text-gray-300';
          if (cmd === 'help') {
            res.innerHTML = `Available commands: status, ps, touch, memory, clear`;
          } else if (cmd === 'status') {
            res.innerHTML = `OmniOS v2 Host Service: RUNNING (PID 14209)<br>Touch Engine: ${this.serverState.adminConfig.touchInputEnabled ? 'ENABLED' : 'DISABLED'}<br>Active Streams: 1 WebClient`;
          } else if (cmd === 'clear') {
            output.innerHTML = '';
            return;
          } else {
            res.textContent = `Executed: ${cmd}`;
          }
          output.appendChild(res);
          output.scrollTop = output.scrollHeight;
        }
      });
    }

    // 7. System Monitor / Host Dashboard
    renderSystemMonitorApp(winId, container, appData) {
      const stats = this.serverState.systemStats;
      container.innerHTML = `
        <div class="sysmon-root p-6">
          <h3 class="text-md font-bold mb-4">Host Android System Diagnostics</h3>
          <div class="sysmon-grid grid grid-cols-2 gap-4">
            <div class="glass-card p-4">
              <div class="text-xs text-muted">CPU Usage</div>
              <div class="text-2xl font-bold sysmon-cpu">${stats.cpu}%</div>
            </div>
            <div class="glass-card p-4">
              <div class="text-xs text-muted">RAM Allocated</div>
              <div class="text-2xl font-bold sysmon-ram">${stats.ram}</div>
            </div>
            <div class="glass-card p-4">
              <div class="text-xs text-muted">Core Temperature</div>
              <div class="text-2xl font-bold sysmon-temp">${stats.temp}°C</div>
            </div>
            <div class="glass-card p-4">
              <div class="text-xs text-muted">Battery Status</div>
              <div class="text-2xl font-bold sysmon-battery">${stats.battery}%</div>
            </div>
          </div>
          <div class="mt-6 glass-card p-4">
            <div class="text-xs text-muted mb-2">Touch Engine & Frame Pacing</div>
            <div class="flex items-center justify-between text-sm">
              <span>Touch Mode:</span>
              <span class="font-bold ${this.serverState.adminConfig.touchInputEnabled ? 'text-green-400' : 'text-red-400'}">
                ${this.serverState.adminConfig.touchInputEnabled ? 'ACTIVE (Low-Latency)' : 'DISABLED BY ADMIN'}
              </span>
            </div>
          </div>
        </div>
      `;
    }

    updateSystemMonitorView() {
      const win = this.dom.windowContainer?.querySelector('[data-app-id="sysmon"]');
      if (!win) return;
      const stats = this.serverState.systemStats;
      const cpu = win.querySelector('.sysmon-cpu');
      const ram = win.querySelector('.sysmon-ram');
      const temp = win.querySelector('.sysmon-temp');
      const bat = win.querySelector('.sysmon-battery');
      if (cpu) cpu.textContent = `${stats.cpu}%`;
      if (ram) ram.textContent = stats.ram;
      if (temp) temp.textContent = `${stats.temp}°C`;
      if (bat) bat.textContent = `${stats.battery}%`;
    }

    // 8. Settings App (Host Admin Filtered)
    renderSettingsApp(winId, container, appData) {
      const vis = this.serverState.adminConfig.settingsVisibility || {};
      const config = this.serverState.adminConfig;

      const activeTab = appData.activeTab || 'appearance';
      const audioRoute = config.audioRoute || 'receiver';

      container.innerHTML = `
        <div class="settings-root p-6">
          <div class="settings-nav mb-6 flex gap-3 border-b pb-3">
            ${vis.appearance ? `<button class="settings-tab-btn ${activeTab === 'appearance' ? 'active' : ''}" data-tab="appearance">Appearance</button>` : ''}
            ${vis.animation ? `<button class="settings-tab-btn ${activeTab === 'animation' ? 'active' : ''}" data-tab="animation">Animations</button>` : ''}
            ${vis.sound ? `<button class="settings-tab-btn ${activeTab === 'sound' ? 'active' : ''}" data-tab="sound">Sound</button>` : ''}
            ${vis.host ? `<button class="settings-tab-btn ${activeTab === 'host' ? 'active' : ''}" data-tab="host">Host Control</button>` : ''}
          </div>

          <div class="settings-pane" id="settings-pane-content">
            <!-- Appearance Tab -->
            <div class="settings-tab-content ${activeTab === 'appearance' ? 'block' : 'hidden'}" id="tab-appearance">
              ${vis.appearance ? `
                <div class="settings-section">
                  <h4 class="font-bold mb-3">Theme Selection</h4>
                  <div class="theme-picker flex gap-3 mb-5">
                    ${['macos', 'windows', 'linux', 'android'].map(t => `
                      <button class="os-btn ${config.theme === t ? 'primary' : ''} theme-select-btn" data-theme="${t}">
                        ${t.toUpperCase()}
                      </button>
                    `).join('')}
                  </div>

                  <h4 class="font-bold mb-2">Display Calibration (Wireless / Web)</h4>
                  <p class="text-xs text-muted mb-3">Applies software luminance shading directly to the video/DOM stream.</p>
                  <div class="flex items-center gap-4 mb-4">
                    <input type="range" min="15" max="100" value="${this.serverState.quickPanel.brightness || 100}" class="settings-brightness-slider" />
                    <span class="settings-brightness-val text-xs font-mono">${this.serverState.quickPanel.brightness || 100}%</span>
                  </div>

                  <div class="flex items-center justify-between p-3 glass-card mb-5">
                    <div>
                      <div class="text-sm font-semibold">Dark Theme Mode</div>
                      <div class="text-2xs text-muted">Switch UI glass elements between dark and light modes</div>
                    </div>
                    <button class="os-btn small toggle-darkmode-btn">
                      ${this.serverState.quickPanel.darkMode ? '🌙 Dark Active' : '☀️ Light Active'}
                    </button>
                  </div>

                  <!-- Fullscreen Control (Automatically suppressed on wireless displays and receiver app) -->
                  <div class="fullscreen-toggle-btn p-3 glass-card mb-5">
                    <div class="flex items-center justify-between">
                      <div>
                        <div class="text-sm font-semibold">Display Window Mode</div>
                        <div class="text-2xs text-muted">Expand workspace to true fullscreen (Web browser mode)</div>
                      </div>
                      <button class="os-btn small trigger-fs-btn">Toggle Fullscreen</button>
                    </div>
                  </div>

                  <!-- Custom Icon Uploader / SVG Injector -->
                  <div class="p-4 glass-card">
                    <h5 class="font-bold text-xs mb-1">Custom Icon Uploader / Vector Override</h5>
                    <p class="text-2xs text-muted mb-3">Paste custom SVG markup or base64 data to replace app icons or the OS brand logo.</p>
                    <div class="flex gap-2 mb-2">
                      <select class="custom-icon-target-select bg-black text-xs text-white p-1 rounded border border-gray-700">
                        <option value="system_logo">OS System Logo (Topbar)</option>
                        <option value="files">Files App</option>
                        <option value="video">Video Player</option>
                        <option value="music">Music App</option>
                        <option value="terminal">Terminal</option>
                        <option value="settings">Settings</option>
                      </select>
                      <button class="os-btn small apply-custom-icon-btn primary">Apply Icon</button>
                    </div>
                    <textarea class="custom-icon-textarea w-full text-2xs font-mono p-2 bg-black text-gray-300 rounded border border-gray-800" rows="3" placeholder="<svg viewBox='0 0 48 48'>...</svg>"></textarea>
                  </div>
                </div>
              ` : '<div class="text-sm text-muted">Appearance settings managed by Host Admin.</div>'}
            </div>

            <!-- Animation Tab -->
            <div class="settings-tab-content ${activeTab === 'animation' ? 'block' : 'hidden'}" id="tab-animation">
              ${vis.animation ? `
                <div class="settings-section">
                  <h4 class="font-bold mb-3">Animation Duration</h4>
                  <div class="flex items-center gap-4">
                    <input type="range" min="100" max="800" step="50" value="${config.animationDuration || 300}" class="anim-duration-slider" />
                    <span class="anim-duration-val">${config.animationDuration || 300}ms</span>
                  </div>
                </div>
              ` : '<div class="text-sm text-muted">Animation speed managed by Host Admin.</div>'}
            </div>

            <!-- Sound & Audio Route Tab -->
            <div class="settings-tab-content ${activeTab === 'sound' ? 'block' : 'hidden'}" id="tab-sound">
              ${vis.sound ? `
                <div class="settings-section">
                  <h4 class="font-bold mb-2">Audio Output Destination</h4>
                  <p class="text-xs text-muted mb-4">Choose where desktop sounds and media playback should be routed.</p>
                  <div class="audio-route-group mb-5">
                    <button class="audio-route-btn ${audioRoute === 'receiver' ? 'active' : ''}" data-audio="receiver">
                      🔊 Casting Receiver Device (Web / Tablet)
                    </button>
                    <button class="audio-route-btn ${audioRoute === 'host' ? 'active' : ''}" data-audio="host">
                      📱 Host Phone Speaker
                    </button>
                    <button class="audio-route-btn ${audioRoute === 'both' ? 'active' : ''}" data-audio="both">
                      🎧 Both Devices Simultaneously
                    </button>
                  </div>

                  <h4 class="font-bold mb-2">Host Volume</h4>
                  <input type="range" min="0" max="100" value="${this.serverState.quickPanel.volume}" class="qp-slider w-full" />
                </div>
              ` : '<div class="text-sm text-muted">Sound settings managed by Host Admin.</div>'}
            </div>

            <!-- Host Control Tab -->
            <div class="settings-tab-content ${activeTab === 'host' ? 'block' : 'hidden'}" id="tab-host">
              ${vis.host ? `
                <div class="settings-section">
                  <h4 class="font-bold mb-2">Host System Authority</h4>
                  <p class="text-xs text-muted mb-3">Settings displayed on this device are governed by the Android host application.</p>
                  <div class="flex flex-col gap-2">
                    <div class="flex items-center justify-between p-3 glass-card">
                      <span class="text-xs">Touch Input Stream:</span>
                      <span class="badge ${config.touchInputEnabled ? 'badge-success' : 'badge-danger'}">
                        ${config.touchInputEnabled ? 'Allowed (Active)' : 'Locked by Host'}
                      </span>
                    </div>
                    <div class="flex items-center justify-between p-3 glass-card">
                      <span class="text-xs">Active Audio Target:</span>
                      <span class="badge badge-success">${(config.audioRoute || 'receiver').toUpperCase()}</span>
                    </div>
                  </div>
                </div>
              ` : ''}
            </div>
          </div>
        </div>
      `;

      // Tab switcher
      container.querySelectorAll('.settings-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const tab = btn.getAttribute('data-tab');
          container.querySelectorAll('.settings-tab-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          container.querySelectorAll('.settings-tab-content').forEach(c => {
            c.classList.add('hidden');
            c.classList.remove('block');
          });
          const target = container.querySelector(`#tab-${tab}`);
          if (target) {
            target.classList.remove('hidden');
            target.classList.add('block');
          }
        });
      });

      // Dark mode toggle in Settings
      const dmBtn = container.querySelector('.toggle-darkmode-btn');
      dmBtn?.addEventListener('click', () => {
        const next = !this.serverState.quickPanel.darkMode;
        this.applyDarkMode(next);
        this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, { cmd: 'set_dark_mode', darkMode: next });
        dmBtn.textContent = next ? '🌙 Dark Active' : '☀️ Light Active';
      });

      // Brightness slider in Settings
      const setBSlider = container.querySelector('.settings-brightness-slider');
      const setBVal = container.querySelector('.settings-brightness-val');
      if (setBSlider) {
        setBSlider.addEventListener('input', (e) => {
          const v = parseInt(e.target.value, 10);
          if (setBVal) setBVal.textContent = `${v}%`;
          this.applyBrightness(v);
        });
        setBSlider.addEventListener('change', (e) => {
          const v = parseInt(e.target.value, 10);
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, { cmd: 'set_brightness', brightness: v });
        });
      }

      // Fullscreen toggle in Settings
      container.querySelector('.trigger-fs-btn')?.addEventListener('click', () => {
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      });

      // Audio route in Settings
      container.querySelectorAll('.audio-route-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const route = btn.getAttribute('data-audio');
          this.serverState.adminConfig.audioRoute = route;
          container.querySelectorAll('.audio-route-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, { cmd: 'set_audio_route', route });
        });
      });

      // Custom icon applicator
      const applyIconBtn = container.querySelector('.apply-custom-icon-btn');
      const iconTarget = container.querySelector('.custom-icon-target-select');
      const iconTextarea = container.querySelector('.custom-icon-textarea');
      applyIconBtn?.addEventListener('click', () => {
        const target = iconTarget?.value;
        const svg = iconTextarea?.value?.trim();
        if (target && svg) {
          if (OmniOS.icons && typeof OmniOS.icons.setCustomIcon === 'function') {
            OmniOS.icons.setCustomIcon(target, svg);
          }
          if (target === 'system_logo') {
            this.updateTopbarLogo();
          }
          this.renderDock();
          this.renderDesktopShortcuts();
          // Dispatch to server so host remembers override
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
            cmd: 'set_custom_icon',
            iconId: target,
            svg: svg
          });
          alert(`Icon for "${target}" applied successfully!`);
        }
      });

      // Event listeners
      container.querySelectorAll('.theme-select-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const newTheme = btn.getAttribute('data-theme');
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
            cmd: 'set_theme',
            theme: newTheme
          });
        });
      });

      const slider = container.querySelector('.anim-duration-slider');
      const valLabel = container.querySelector('.anim-duration-val');
      if (slider && valLabel) {
        slider.addEventListener('input', (e) => {
          valLabel.textContent = `${e.target.value}ms`;
        });
        slider.addEventListener('change', (e) => {
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
            cmd: 'set_animation_duration',
            duration: parseInt(e.target.value, 10)
          });
        });
      }
    }

    patchOpenSettingsWindow() {
      const settingsWin = this.dom.windowContainer?.querySelector('[data-app-id="settings"]');
      if (settingsWin) {
        const bodyEl = settingsWin.querySelector('.window-content');
        if (bodyEl) {
          this.renderSettingsApp('win-settings', bodyEl);
        }
      }
    }

    /* ==========================================================================
       Dock & Desktop Icons Rendering
       ========================================================================== */

    renderDock() {
      if (!this.dom.dock) return;
      const allowedApps = this.serverState.adminConfig.allowedApps || [];

      const appDefs = [
        { id: 'files', name: 'Files' },
        { id: 'video', name: 'Video Player' },
        { id: 'music', name: 'Music' },
        { id: 'pdf', name: 'PDF Reader' },
        { id: 'notes', name: 'Text Editor' },
        { id: 'terminal', name: 'Terminal' },
        { id: 'sysmon', name: 'Host Monitor' },
        { id: 'settings', name: 'Settings' }
      ];

      // Filter only apps allowed by host admin
      const filtered = appDefs.filter(app => allowedApps.includes(app.id));

      this.dom.dock.innerHTML = filtered.map(app => `
        <div class="dock-item" data-app-id="${app.id}" title="${app.name}">
          <div class="dock-icon-wrapper">
            ${this.getAppIconSvg(app.id, 42)}
          </div>
          <div class="dock-dot"></div>
        </div>
      `).join('');

      // Attach click handlers
      this.dom.dock.querySelectorAll('.dock-item').forEach(item => {
        item.addEventListener('click', (e) => {
          const appId = item.getAttribute('data-app-id');
          this.handleDockAppClick(appId);
        });
      });

      this.updateDockRunningIndicators();
    }

    handleDockAppClick(appId) {
      // Check if window already exists in server state
      const existing = Object.entries(this.serverState.windows).find(([id, w]) => w.appId === appId);

      if (existing) {
        const [winId, w] = existing;
        if (w.isMinimized) {
          this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'restore', winId });
        } else if (w.isFocused) {
          this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'minimize', winId });
        } else {
          this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'focus', winId });
        }
      } else {
        // Request host server to instantiate new window
        this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'open', appId });
      }
    }

    updateDockRunningIndicators() {
      if (!this.dom.dock) return;
      const runningApps = new Set(Object.values(this.serverState.windows).map(w => w.appId));

      this.dom.dock.querySelectorAll('.dock-item').forEach(item => {
        const appId = item.getAttribute('data-app-id');
        item.classList.toggle('running', runningApps.has(appId));
      });
    }

    renderDesktopShortcuts() {
      const desktopIconsContainer = document.getElementById('desktop-icons');
      if (!desktopIconsContainer) return;

      const allowedApps = this.serverState.adminConfig.allowedApps || [];
      const appDefs = [
        { id: 'files', name: 'Files' },
        { id: 'video', name: 'Video' },
        { id: 'music', name: 'Music' },
        { id: 'pdf', name: 'PDF Docs' },
        { id: 'notes', name: 'Notes' },
        { id: 'sysmon', name: 'Host Diagnostics' },
        { id: 'settings', name: 'Settings' }
      ];

      const filtered = appDefs.filter(app => allowedApps.includes(app.id));

      desktopIconsContainer.innerHTML = filtered.map(app => `
        <div class="desktop-shortcut" data-app-id="${app.id}">
          <div class="shortcut-icon">${this.getAppIconSvg(app.id, 46)}</div>
          <div class="shortcut-label">${app.name}</div>
        </div>
      `).join('');

      desktopIconsContainer.querySelectorAll('.desktop-shortcut').forEach(sc => {
        sc.addEventListener('dblclick', () => {
          const appId = sc.getAttribute('data-app-id');
          this.send(OmniOSProtocol.OPCODES.WINDOW_ACTION, { action: 'open', appId });
        });
      });
    }

    /* ==========================================================================
       Quick Panel & Notification Center
       ========================================================================== */

    renderQuickPanel() {
      if (!this.dom.quickPanel) return;
      const qp = this.serverState.quickPanel;
      const audioRoute = this.serverState.adminConfig.audioRoute || 'receiver';

      this.dom.quickPanel.innerHTML = `
        <div class="quick-panel-card glass-panel p-5">
          <div class="grid grid-cols-2 gap-3 mb-4">
            <button class="qp-tile ${qp.wifi ? 'active' : ''}" data-feature="wifi">
              <span>📶</span>
              <span class="text-xs font-semibold">Wi-Fi</span>
            </button>
            <button class="qp-tile ${qp.bluetooth ? 'active' : ''}" data-feature="bluetooth">
              <span>ᛒ</span>
              <span class="text-xs font-semibold">Bluetooth</span>
            </button>
            <button class="qp-tile ${qp.darkMode ? 'active' : ''}" data-feature="darkMode">
              <span>🌙</span>
              <span class="text-xs font-semibold">Dark Mode</span>
            </button>
            <button class="qp-tile ${this.serverState.adminConfig.touchInputEnabled ? 'active' : 'disabled'}" data-feature="touch">
              <span>👆</span>
              <span class="text-xs font-semibold">Touch</span>
            </button>
          </div>

          <!-- Audio Destination Route Selector -->
          <div class="mb-4">
            <label class="text-xs font-semibold text-muted block mb-1.5">Audio Output Route</label>
            <div class="audio-route-group">
              <button class="audio-route-btn ${audioRoute === 'receiver' ? 'active' : ''}" data-audio="receiver" title="Play on this client screen/device">
                🔊 Receiver
              </button>
              <button class="audio-route-btn ${audioRoute === 'host' ? 'active' : ''}" data-audio="host" title="Play on Host Phone speaker">
                📱 Host
              </button>
              <button class="audio-route-btn ${audioRoute === 'both' ? 'active' : ''}" data-audio="both" title="Play on both devices simultaneously">
                🎧 Both
              </button>
            </div>
          </div>

          <!-- True Software Luminance Brightness for Wireless Displays -->
          <div class="slider-group mb-3">
            <div class="flex justify-between items-center mb-1">
              <label class="text-xs font-semibold text-muted">Display Brightness</label>
              <span class="text-2xs font-mono text-muted qp-brightness-val">${qp.brightness || 100}%</span>
            </div>
            <input type="range" min="15" max="100" value="${qp.brightness || 100}" class="qp-slider" data-param="brightness" />
          </div>

          <!-- Host Audio Volume -->
          <div class="slider-group">
            <div class="flex justify-between items-center mb-1">
              <label class="text-xs font-semibold text-muted">Host Volume</label>
              <span class="text-2xs font-mono text-muted">${qp.volume}%</span>
            </div>
            <input type="range" min="0" max="100" value="${qp.volume}" class="qp-slider" data-param="volume" />
          </div>
        </div>
      `;

      // Tile clicks
      this.dom.quickPanel.querySelectorAll('.qp-tile').forEach(tile => {
        tile.addEventListener('click', () => {
          const feat = tile.getAttribute('data-feature');
          if (feat === 'touch') {
            this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
              cmd: 'toggle_touch',
              enabled: !this.serverState.adminConfig.touchInputEnabled
            });
          } else if (feat === 'darkMode') {
            const nextMode = !this.serverState.quickPanel.darkMode;
            this.applyDarkMode(nextMode);
            this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
              cmd: 'set_dark_mode',
              darkMode: nextMode
            });
          } else {
            this.send(OmniOSProtocol.OPCODES.APP_ACTION, {
              appId: 'system',
              action: 'toggle_quick_panel',
              feature: feat
            });
          }
        });
      });

      // Audio route buttons
      this.dom.quickPanel.querySelectorAll('.audio-route-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const route = btn.getAttribute('data-audio');
          this.serverState.adminConfig.audioRoute = route;
          this.dom.quickPanel.querySelectorAll('.audio-route-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
            cmd: 'set_audio_route',
            route: route
          });
        });
      });

      // Brightness slider (real-time software luminance filter)
      const bSlider = this.dom.quickPanel.querySelector('[data-param="brightness"]');
      const bVal = this.dom.quickPanel.querySelector('.qp-brightness-val');
      if (bSlider) {
        bSlider.addEventListener('input', (e) => {
          const val = parseInt(e.target.value, 10);
          if (bVal) bVal.textContent = `${val}%`;
          this.applyBrightness(val);
        });
        bSlider.addEventListener('change', (e) => {
          const val = parseInt(e.target.value, 10);
          this.send(OmniOSProtocol.OPCODES.ADMIN_COMMAND, {
            cmd: 'set_brightness',
            brightness: val
          });
        });
      }
    }

    toggleQuickPanel() {
      if (!this.dom.quickPanel) return;
      this.dom.quickPanel.classList.toggle('open');
      this.dom.notificationCenter?.classList.remove('open');
    }

    renderNotifications() {
      if (!this.dom.notificationCenter) return;
      const notifs = this.serverState.notifications || [];

      this.dom.notificationCenter.innerHTML = `
        <div class="notif-center-root glass-panel p-4">
          <div class="flex items-center justify-between mb-4 pb-2 border-b">
            <span class="font-bold text-sm">Notifications (${notifs.length})</span>
            <button class="text-xs text-muted clear-notifs-btn">Clear All</button>
          </div>
          <div class="notif-list flex flex-col gap-3">
            ${notifs.length === 0 ? '<div class="text-center text-xs text-muted py-6">No notifications</div>' : ''}
            ${notifs.map(n => `
              <div class="notif-card glass-card p-3" data-id="${n.id}">
                <div class="flex items-center justify-between mb-1">
                  <span class="font-semibold text-xs">${n.title}</span>
                  <span class="text-2xs text-muted">${n.time || 'now'}</span>
                </div>
                <div class="text-xs text-muted">${n.body}</div>
                <button class="notif-dismiss-btn" data-id="${n.id}">✕</button>
              </div>
            `).join('')}
          </div>
        </div>
      `;

      this.dom.notificationCenter.querySelectorAll('.notif-dismiss-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const id = btn.getAttribute('data-id');
          this.send(OmniOSProtocol.OPCODES.APP_ACTION, {
            appId: 'system',
            action: 'dismiss_notification',
            id
          });
        });
      });
    }

    toggleNotificationCenter() {
      if (!this.dom.notificationCenter) return;
      this.dom.notificationCenter.classList.toggle('open');
      this.dom.quickPanel?.classList.remove('open');
    }

    closePopups() {
      this.dom.quickPanel?.classList.remove('open');
      this.dom.notificationCenter?.classList.remove('open');
    }

    showNotificationToast(notif) {
      const toast = document.createElement('div');
      toast.className = 'notif-toast glass-card';
      toast.innerHTML = `
        <div class="font-bold text-xs">${notif.title}</div>
        <div class="text-xs text-muted">${notif.body}</div>
      `;
      document.body.appendChild(toast);
      setTimeout(() => toast.classList.add('visible'), 10);
      setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 300);
      }, 4000);
    }

    getAppIconSvg(appId, size = 32) {
      const theme = this.serverState.adminConfig.theme || 'macos';
      if (OmniOS.Themes && typeof OmniOS.Themes.getAppIcon === 'function') {
        return OmniOS.Themes.getAppIcon(appId, size, theme);
      }
      return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="currentColor"><rect width="24" height="24" rx="4" fill="#007AFF"/></svg>`;
    }
  }

  OmniOS.SDUIClient = SDUIClient;

  // Auto-boot upon DOM ready
  document.addEventListener('DOMContentLoaded', () => {
    const client = new SDUIClient();
    window.OmniOSClientInstance = client;
    client.init();
  });
})(window.OmniOS);
