package com.omnios.v2.host

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * OmniOS v2 - Touch Ingestion & Injection Pipeline
 * Maps normalized client touch coordinates to native screen or VirtualDisplay pixels.
 * Injects touch gestures via Android AccessibilityService with adaptive backpressure control.
 */
class TouchInjectionManager(
    private val adminConfig: AdminConfig,
    var hostScreenWidth: Int = 1920,
    var hostScreenHeight: Int = 1080
) {
    companion object {
        private const val TAG = "OmniOS:TouchManager"
        var activeAccessibilityService: AccessibilityService? = null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val isDispatchingGesture = AtomicBoolean(false)
    private var currentPath: Path? = null
    private var lastX: Float = 0f
    private var lastY: Float = 0f
    private var strokeStartTime: Long = 0

    // Backpressure: holds latest pending move to prevent gesture queue overflow
    private var pendingMoveX: Float? = null
    private var pendingMoveY: Float? = null

    /**
     * Ingests a touch event with normalized coordinates (0.0 .. 1.0).
     * @param action 1=DOWN, 2=MOVE, 3=UP, 4=CANCEL
     */
    fun ingestTouch(action: Int, pointerId: Int, normX: Float, normY: Float, timestampMs: Long) {
        // 1. Host Admin Touch Gate
        if (!adminConfig.touchInputEnabled) {
            Log.d(TAG, "Touch event ignored: Touch input disabled by Host Admin.")
            return
        }

        // 2. Coordinate Transformation (Normalized -> Host Physical / VirtualDisplay Pixels)
        val pixelX = (normX.coerceIn(0f, 1f) * hostScreenWidth)
        val pixelY = (normY.coerceIn(0f, 1f) * hostScreenHeight)

        when (action) {
            0x01 -> handleTouchDown(pixelX, pixelY)
            0x02 -> handleTouchMove(pixelX, pixelY)
            0x03 -> handleTouchUp(pixelX, pixelY)
            0x04 -> handleTouchCancel()
        }
    }

    private fun handleTouchDown(x: Float, y: Float) {
        lastX = x
        lastY = y
        strokeStartTime = System.currentTimeMillis()

        currentPath = Path().apply {
            moveTo(x, y)
        }
    }

    private fun handleTouchMove(x: Float, y: Float) {
        if (currentPath == null) return

        // Adaptive backpressure queue: If AccessibilityService is still processing
        // previous stroke, retain latest point to avoid frame lag
        if (isDispatchingGesture.get()) {
            pendingMoveX = x
            pendingMoveY = y
            return
        }

        dispatchMoveSegment(x, y)
    }

    private fun dispatchMoveSegment(x: Float, y: Float) {
        val service = activeAccessibilityService ?: return
        val path = Path().apply {
            moveTo(lastX, lastY)
            lineTo(x, y)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, 45, true)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        isDispatchingGesture.set(true)
        lastX = x
        lastY = y

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                isDispatchingGesture.set(false)
                // Flush pending move if queued during dispatch
                val px = pendingMoveX
                val py = pendingMoveY
                if (px != null && py != null) {
                    pendingMoveX = null
                    pendingMoveY = null
                    dispatchMoveSegment(px, py)
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                isDispatchingGesture.set(false)
                pendingMoveX = null
                pendingMoveY = null
            }
        }, mainHandler)
    }

    private fun handleTouchUp(x: Float, y: Float) {
        val service = activeAccessibilityService
        if (service == null) {
            currentPath = null
            return
        }

        val duration = (System.currentTimeMillis() - strokeStartTime).coerceIn(40, 150)
        val path = Path().apply {
            moveTo(lastX, lastY)
            lineTo(x, y)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, duration, false)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGesture(gesture, null, mainHandler)
        currentPath = null
        pendingMoveX = null
        pendingMoveY = null
    }

    private fun handleTouchCancel() {
        currentPath = null
        pendingMoveX = null
        pendingMoveY = null
        isDispatchingGesture.set(false)
    }
}
