package com.omnios.v2.host

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * OmniOS v2 - Host Admin Configuration Model
 * Holds authoritative permissions, touch gates, audio routing, and display calibration.
 */
data class AdminConfig(
    var touchInputEnabled: Boolean = true,
    var audioRoute: String = "receiver", // "receiver", "host", "both"
    var brightness: Int = 100, // 15..100 software luminance
    var darkMode: Boolean = true,
    var allowedApps: MutableList<String> = mutableListOf(
        "files", "video", "music", "pdf", "notes", "terminal", "sysmon", "settings"
    ),
    var settingsVisibility: MutableMap<String, Boolean> = mutableMapOf(
        "appearance" to true,
        "animation" to true,
        "sound" to true,
        "storage" to true,
        "host" to true
    ),
    var theme: String = "macos",
    var animationDurationMs: Int = 300,
    var fileSandboxPath: String = "/sdcard/OmniOS/Sandbox",
    var maxFps: Int = 60,
    var requireAuthToken: Boolean = false,
    var authToken: String = "",
    var customIcons: MutableMap<String, String> = mutableMapOf()
) {
    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("touchInputEnabled", touchInputEnabled)
        json.put("audioRoute", audioRoute)
        json.put("brightness", brightness)
        json.put("darkMode", darkMode)
        json.put("allowedApps", JSONArray(allowedApps))

        val visJson = JSONObject()
        for ((k, v) in settingsVisibility) {
            visJson.put(k, v)
        }
        json.put("settingsVisibility", visJson)
        json.put("theme", theme)
        json.put("animationDuration", animationDurationMs)
        json.put("fileSandboxPath", fileSandboxPath)
        json.put("maxFps", maxFps)

        val iconsJson = JSONObject()
        for ((k, v) in customIcons) {
            iconsJson.put(k, v)
        }
        json.put("customIcons", iconsJson)

        return json
    }

    companion object {
        private const val PREFS_NAME = "omnios_admin_config"

        fun load(context: Context): AdminConfig {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val config = AdminConfig()
            config.touchInputEnabled = prefs.getBoolean("touch_enabled", true)
            config.audioRoute = prefs.getString("audio_route", "receiver") ?: "receiver"
            config.brightness = prefs.getInt("brightness", 100)
            config.darkMode = prefs.getBoolean("dark_mode", true)
            config.theme = prefs.getString("theme", "macos") ?: "macos"
            config.animationDurationMs = prefs.getInt("anim_duration", 300)
            config.fileSandboxPath = prefs.getString("sandbox_path", "/sdcard/OmniOS/Sandbox") ?: "/sdcard/OmniOS/Sandbox"

            val appsJson = prefs.getString("allowed_apps", null)
            if (appsJson != null) {
                try {
                    val arr = JSONArray(appsJson)
                    config.allowedApps.clear()
                    for (i in 0 until arr.length()) {
                        config.allowedApps.add(arr.getString(i))
                    }
                } catch (ignored: Exception) {}
            }
            return config
        }

        fun save(context: Context, config: AdminConfig) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putBoolean("touch_enabled", config.touchInputEnabled)
                .putString("audio_route", config.audioRoute)
                .putInt("brightness", config.brightness)
                .putBoolean("dark_mode", config.darkMode)
                .putString("theme", config.theme)
                .putInt("anim_duration", config.animationDurationMs)
                .putString("sandbox_path", config.fileSandboxPath)
                .putString("allowed_apps", JSONArray(config.allowedApps).toString())
                .apply()
        }
    }
}
