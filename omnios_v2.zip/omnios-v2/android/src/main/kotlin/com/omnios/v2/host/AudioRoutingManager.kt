package com.omnios.v2.host

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log
import java.nio.ByteBuffer

/**
 * OmniOS v2 - Host Audio Routing Engine
 * Dynamically switches audio output between Host Phone, Wireless Receiver, or Simultaneous Both.
 * Captures internal system audio via Android 10+ AudioPlaybackCapture.
 */
class AudioRoutingManager(
    private val context: Context,
    private val adminConfig: AdminConfig
) {
    companion object {
        private const val TAG = "OmniOS:AudioRouting"
        const val ROUTE_RECEIVER = "receiver"
        const val ROUTE_HOST = "host"
        const val ROUTE_BOTH = "both"

        private const val SAMPLE_RATE = 44100
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private var audioRecord: AudioRecord? = null
    private var localPlaybackTrack: AudioTrack? = null
    private var isCapturing = false
    private var captureThread: Thread? = null

    var onAudioFrameEncoded: ((pcmChunk: ByteArray) -> Unit)? = null

    /**
     * Starts internal audio capture using MediaProjection.
     */
    @SuppressLint("MissingPermission")
    fun startCapture(mediaProjection: MediaProjection) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Log.w(TAG, "AudioPlaybackCapture requires Android 10 (API 29) or higher.")
            return
        }
        if (isCapturing) return

        try {
            val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()

            val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT) * 2

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AUDIO_FORMAT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(CHANNEL_CONFIG)
                .build()

            audioRecord = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(captureConfig)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .build()

            setupLocalPlaybackTrack(bufferSize)

            audioRecord?.startRecording()
            isCapturing = true

            captureThread = Thread {
                val chunk = ByteArray(2048)
                while (isCapturing) {
                    val read = audioRecord?.read(chunk, 0, chunk.size) ?: 0
                    if (read > 0) {
                        val route = adminConfig.audioRoute

                        // 1. Play on Host Device if route is HOST or BOTH
                        if (route == ROUTE_HOST || route == ROUTE_BOTH) {
                            localPlaybackTrack?.write(chunk, 0, read)
                        }

                        // 2. Stream to Wireless / Web Receiver if route is RECEIVER or BOTH
                        if (route == ROUTE_RECEIVER || route == ROUTE_BOTH) {
                            val payload = ByteArray(read)
                            System.arraycopy(chunk, 0, payload, 0, read)
                            onAudioFrameEncoded?.invoke(payload)
                        }
                    }
                }
            }.apply {
                priority = Thread.MAX_PRIORITY
                start()
            }

            Log.i(TAG, "AudioPlaybackCapture active. Current route: ${adminConfig.audioRoute}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start AudioCapture: ${e.message}", e)
        }
    }

    private fun setupLocalPlaybackTrack(bufferSize: Int) {
        try {
            localPlaybackTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            localPlaybackTrack?.play()
        } catch (e: Exception) {
            Log.w(TAG, "Could not initialize local audio track for dual playback: ${e.message}")
        }
    }

    fun setAudioRoute(route: String) {
        if (route == ROUTE_RECEIVER || route == ROUTE_HOST || route == ROUTE_BOTH) {
            adminConfig.audioRoute = route
            Log.i(TAG, "Audio routing target updated to: $route")
        }
    }

    fun stop() {
        isCapturing = false
        captureThread?.interrupt()
        captureThread = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (ignored: Exception) {}
        audioRecord = null

        try {
            localPlaybackTrack?.stop()
            localPlaybackTrack?.release()
        } catch (ignored: Exception) {}
        localPlaybackTrack = null

        Log.i(TAG, "AudioRoutingManager stopped.")
    }
}
