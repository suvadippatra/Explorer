package com.omnios.v2.host.receiver

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceView
import java.nio.ByteBuffer

/**
 * OmniOS v2 - Native Android Receiver Touch Surface
 * Intercepts touch gestures on tablet/phone receiver screens, normalizes coordinates
 * to [0.0, 1.0], and dispatches 10-byte binary packets to the Host Phone.
 */
class RemoteTouchView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs) {

    var onBinaryTouchPacketReady: ((packet: ByteArray) -> Unit)? = null

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val listener = onBinaryTouchPacketReady ?: return super.onTouchEvent(event)

        val pointerIndex = event.actionIndex
        val pointerId = event.getPointerId(pointerIndex)
        val rawX = event.getX(pointerIndex)
        val rawY = event.getY(pointerIndex)

        // Normalize coordinates to 0.0 .. 1.0 float space
        val normX = (rawX / width.toFloat()).coerceIn(0f, 1f)
        val normY = (rawY / height.toFloat()).coerceIn(0f, 1f)

        val opcode = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> 0x01
            MotionEvent.ACTION_MOVE -> 0x02
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> 0x03
            MotionEvent.ACTION_CANCEL -> 0x04
            else -> return super.onTouchEvent(event)
        }

        val packet = encode10ByteTouch(opcode, pointerId, normX, normY, System.currentTimeMillis())
        listener.invoke(packet)

        return true
    }

    /**
     * Packs touch event into exact 10-byte binary specification:
     * [0]: Opcode (1B)
     * [1]: Pointer ID (1B)
     * [2..3]: Normalized X uint16 (2B)
     * [4..5]: Normalized Y uint16 (2B)
     * [6..9]: Timestamp ms uint32 (4B)
     */
    private fun encode10ByteTouch(opcode: Int, pointerId: Int, normX: Float, normY: Float, timestampMs: Long): ByteArray {
        val buffer = ByteBuffer.allocate(10)
        buffer.put(opcode.toByte())
        buffer.put(pointerId.toByte())
        buffer.putShort((normX * 65535.0f).toInt().toShort())
        buffer.putShort((normY * 65535.0f).toInt().toShort())
        buffer.putInt(timestampMs.toInt())
        return buffer.array()
    }
}
