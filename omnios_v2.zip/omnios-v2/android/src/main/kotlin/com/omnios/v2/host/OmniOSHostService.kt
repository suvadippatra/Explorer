package com.omnios.v2.host

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log

/**
 * OmniOS v2 - Foreground Host Service
 * Ensures the Android backend never crashes, sleeps, or throttles.
 * Holds PARTIAL_WAKE_LOCK, high-performance WifiLock, and thermal listener.
 */
class OmniOSHostService : Service() {

    companion object {
        private const val TAG = "OmniOS:HostService"
        private const val NOTIFICATION_ID = 20261
        private const val CHANNEL_ID = "omnios_host_channel"

        const val ACTION_START = "com.omnios.v2.START_HOST"
        const val ACTION_STOP = "com.omnios.v2.STOP_HOST"
        const val ACTION_TOGGLE_TOUCH = "com.omnios.v2.TOGGLE_TOUCH"

        var instance: OmniOSHostService? = null
            private set
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var ktorServer: KtorServer? = null
    lateinit var adminConfig: AdminConfig
        private set
    lateinit var touchManager: TouchInjectionManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.i(TAG, "Initializing OmniOS Host Service...")

        // 1. Crash Shield: Global uncaught exception protection
        setupCrashBoundary()

        // 2. Load Host Admin Configuration
        adminConfig = AdminConfig.load(this)

        // 3. Initialize Touch Pipeline
        touchManager = TouchInjectionManager(adminConfig)

        // 4. Acquire WakeLock and WifiLock (Prevents throttling & radio sleep)
        acquireLocks()

        // 5. Thermal Throttling Mitigation (Android 10+)
        setupThermalMitigation()

        // 6. Launch Embedded Ktor Server
        startKtorServer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, buildForegroundNotification())
                Log.i(TAG, "OmniOS Host Service running in foreground.")
            }
            ACTION_TOGGLE_TOUCH -> {
                val newState = intent?.getBooleanExtra("touch_enabled", !adminConfig.touchInputEnabled) ?: !adminConfig.touchInputEnabled
                adminConfig.touchInputEnabled = newState
                AdminConfig.save(this, adminConfig)
                ktorServer?.broadcastAdminConfig()
                updateNotification()
            }
            ACTION_STOP -> {
                stopSelf()
            }
        }

        // START_STICKY ensures Android OS resurrects the service if killed under memory pressure
        return START_STICKY
    }

    private fun acquireLocks() {
        // CPU Partial WakeLock: CPU remains awake even if display is turned off
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OmniOS:HostCpuWakeLock").apply {
            setReferenceCounted(false)
            acquire(24 * 60 * 60 * 1000L) // 24 hours max safeguard
        }

        // High-Performance Low-Latency WifiLock
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }

        wifiLock = wifiManager.createWifiLock(lockMode, "OmniOS:HostWifiLock").apply {
            setReferenceCounted(false)
            acquire()
        }

        Log.i(TAG, "Acquired PARTIAL_WAKE_LOCK & Low-Latency WifiLock.")
    }

    private fun setupThermalMitigation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            powerManager.addThermalStatusListener { status ->
                when (status) {
                    PowerManager.THERMAL_STATUS_MODERATE -> {
                        Log.w(TAG, "Thermal Status: MODERATE. Adjusting frame target to 45fps.")
                    }
                    PowerManager.THERMAL_STATUS_SEVERE, PowerManager.THERMAL_STATUS_CRITICAL -> {
                        Log.e(TAG, "Thermal Status: CRITICAL. Reducing pacing to 30fps to avoid OS throttling.")
                        adminConfig.maxFps = 30
                        ktorServer?.broadcastAdminConfig()
                    }
                    PowerManager.THERMAL_STATUS_NONE -> {
                        adminConfig.maxFps = 60
                    }
                }
            }
        }
    }

    private fun setupCrashBoundary() {
        val originalHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e(TAG, "Crash boundary intercepted exception on thread ${thread.name}: ${throwable.message}", throwable)
            // Prevent JVM termination; log and keep foreground service alive
        }
    }

    private fun startKtorServer() {
        try {
            ktorServer = KtorServer(this, adminConfig, touchManager, port = 8080)
            ktorServer?.start()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Ktor Server: ${e.message}", e)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OmniOS Host Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Runs the server-authoritative SDUI and touch casting pipeline"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openIntent = Intent(this, AdminSettingsActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val touchStateText = if (adminConfig.touchInputEnabled) "Touch Input: ALLOWED" else "Touch Input: LOCKED"

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("OmniOS v2 Host Server Running")
            .setContentText("Port 8080 | $touchStateText")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildForegroundNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "Shutting down OmniOS Host Service...")

        try { ktorServer?.stop() } catch (ignored: Exception) {}
        try { wakeLock?.release() } catch (ignored: Exception) {}
        try { wifiLock?.release() } catch (ignored: Exception) {}

        instance = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
