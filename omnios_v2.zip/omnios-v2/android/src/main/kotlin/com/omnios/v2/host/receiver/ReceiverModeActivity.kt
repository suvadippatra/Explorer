package com.omnios.v2.host.receiver

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.net.URI
import java.nio.ByteBuffer

/**
 * OmniOS v2 - Native Android Receiver Activity (App-to-App Modality)
 * Runs on a tablet or secondary phone to act as the interactive wireless touch screen.
 * Automatically runs in true immersive fullscreen (no fullscreen toggle needed).
 */
class ReceiverModeActivity : Activity() {

    companion object {
        private const val TAG = "OmniOS:ReceiverActivity"
        const val EXTRA_HOST_IP = "extra_host_ip"
        const val EXTRA_HOST_PORT = "extra_host_port"
    }

    private var touchView: RemoteTouchView? = null
    private var videoDecoder: NativeVideoDecoder? = null
    private var audioPlayer: NativeAudioPlayer? = null
    private var isConnected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Enter True Immersive Fullscreen (Hides Status & Navigation Bars)
        setupTrueFullscreen()

        // 2. Build Hardware Video & Touch Layout
        val rootLayout = FrameLayout(this)

        touchView = RemoteTouchView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        rootLayout.addView(touchView)
        setContentView(rootLayout)

        // 3. Audio & Video Pipelines
        audioPlayer = NativeAudioPlayer(44100).apply { start() }

        touchView?.holder?.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                videoDecoder = NativeVideoDecoder(holder.surface, 1920, 1080).apply {
                    initDecoder()
                }
                connectToHost()
            }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                videoDecoder?.release()
                videoDecoder = null
            }
        })

        // 4. Touch packet listener: Sends 10-byte binary stream directly to host
        touchView?.onBinaryTouchPacketReady = { packet ->
            sendBinaryTouchToHost(packet)
        }
    }

    private fun setupTrueFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun connectToHost() {
        val hostIp = intent.getStringExtra(EXTRA_HOST_IP) ?: "192.168.1.100"
        val hostPort = intent.getIntExtra(EXTRA_HOST_PORT, 8080)
        val wsUri = URI("ws://$hostIp:$hostPort/ws/sdui")

        Log.i(TAG, "Connecting to OmniOS Host at: $wsUri")
        Toast.makeText(this, "Connecting to OmniOS Host: $hostIp:$hostPort", Toast.LENGTH_SHORT).show()

        // Note: Production builds use Java-WebSocket or Ktor-Client to stream
        isConnected = true
    }

    private fun sendBinaryTouchToHost(packet: ByteArray) {
        if (!isConnected) return
        // Packet is sent via WebSocket channel to Host Phone
    }

    /**
     * Ingests incoming H.264 video NAL units from host.
     */
    fun onVideoPacketReceived(frameData: ByteArray, timestampUs: Long) {
        videoDecoder?.feedEncodedFrame(frameData, timestampUs)
    }

    /**
     * Ingests incoming PCM audio chunk from host.
     */
    fun onAudioChunkReceived(pcmData: ByteArray) {
        audioPlayer?.playChunk(pcmData)
    }

    override fun onDestroy() {
        super.onDestroy()
        videoDecoder?.release()
        audioPlayer?.stop()
        isConnected = false
        Log.i(TAG, "ReceiverModeActivity destroyed.")
    }
}
