package com.omnios.v2.host

import android.content.Context
import android.util.Log
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.ClosedReceiveChannelException
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

/**
 * OmniOS v2 - Embedded Ktor Server for Android
 * Hosts the Server-Driven UI (SDUI) web client, WebSocket pipeline, and Admin REST API.
 */
class KtorServer(
    private val context: Context,
    private val adminConfig: AdminConfig,
    private val touchManager: TouchInjectionManager,
    private val port: Int = 8080
) {
    companion object {
        private const val TAG = "OmniOS:KtorServer"
    }

    private var serverEngine: ApplicationEngine? = null
    private val activeSessions = ConcurrentHashMap<String, WebSocketSession>()
    private val serverScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun start() {
        serverEngine = embeddedServer(Netty, port = port, host = "0.0.0.0") {
            install(WebSockets) {
                pingPeriodMillis = 10_000
                timeoutMillis = 15_000
                maxFrameSize = 1024 * 1024
            }

            routing {
                // 1. Static Client Assets
                get("/") {
                    serveAsset(call, "index.html", "text/html")
                }
                get("/index.html") {
                    serveAsset(call, "index.html", "text/html")
                }
                get("/css/{filename...}") {
                    val path = call.parameters.getAll("filename")?.joinToString("/") ?: ""
                    serveAsset(call, "css/$path", "text/css")
                }
                get("/js/{filename...}") {
                    val path = call.parameters.getAll("filename")?.joinToString("/") ?: ""
                    serveAsset(call, "js/$path", "application/javascript")
                }
                get("/assets/{filename...}") {
                    val path = call.parameters.getAll("filename")?.joinToString("/") ?: ""
                    serveAsset(call, "assets/$path", getMimeType(path))
                }

                // 2. Admin REST Control API
                route("/api/admin") {
                    get("/status") {
                        val status = JSONObject().apply {
                            put("success", true)
                            put("engine", "OmniOS v2 Kotlin/Ktor Host Engine")
                            put("activeSessions", activeSessions.size)
                            put("config", adminConfig.toJson())
                        }
                        call.respondText(status.toString(), ContentType.Application.Json)
                    }

                    post("/touch") {
                        val body = call.receiveText()
                        val json = JSONObject(body)
                        val enabled = json.optBoolean("enabled", true)
                        adminConfig.touchInputEnabled = enabled
                        AdminConfig.save(context, adminConfig)
                        broadcastAdminConfig()
                        call.respondText("""{"success":true,"touchInputEnabled":$enabled}""", ContentType.Application.Json)
                    }

                    post("/apps") {
                        val body = call.receiveText()
                        val json = JSONObject(body)
                        val appsArr = json.optJSONArray("apps")
                        if (appsArr != null) {
                            adminConfig.allowedApps.clear()
                            for (i in 0 until appsArr.length()) {
                                adminConfig.allowedApps.add(appsArr.getString(i))
                            }
                            AdminConfig.save(context, adminConfig)
                            broadcastAdminConfig()
                        }
                        call.respondText("""{"success":true}""", ContentType.Application.Json)
                    }

                    post("/audio-route") {
                        val body = call.receiveText()
                        val json = JSONObject(body)
                        val route = json.optString("route", "receiver")
                        adminConfig.audioRoute = route
                        AdminConfig.save(context, adminConfig)
                        broadcastAdminConfig()
                        call.respondText("""{"success":true,"audioRoute":"$route"}""", ContentType.Application.Json)
                    }

                    post("/brightness") {
                        val body = call.receiveText()
                        val json = JSONObject(body)
                        val b = json.optInt("brightness", 100)
                        adminConfig.brightness = b
                        AdminConfig.save(context, adminConfig)
                        broadcastAdminConfig()
                        call.respondText("""{"success":true,"brightness":$b}""", ContentType.Application.Json)
                    }

                    post("/icons") {
                        val body = call.receiveText()
                        val json = JSONObject(body)
                        val iconsObj = json.optJSONObject("icons")
                        if (iconsObj != null) {
                            for (key in iconsObj.keys()) {
                                adminConfig.customIcons[key] = iconsObj.getString(key)
                            }
                            broadcastAdminConfig()
                        }
                        call.respondText("""{"success":true}""", ContentType.Application.Json)
                    }
                }

                // 3. WebSocket SDUI & Touch Stream Pipeline
                webSocket("/ws/sdui") {
                    val sessionId = System.currentTimeMillis().toString() + "_" + (1000..9999).random()
                    activeSessions[sessionId] = this
                    Log.i(TAG, "Client connected: $sessionId. Total clients: ${activeSessions.size}")

                    try {
                        // Send initial full state sync
                        val fullSync = JSONObject().apply {
                            put("op", 0x21) // FULL_SYNC
                            put("state", getInitialStateJson())
                        }
                        send(Frame.Text(fullSync.toString()))

                        for (frame in incoming) {
                            when (frame) {
                                is Frame.Binary -> {
                                    handleBinaryTouchPacket(frame.readBytes())
                                }
                                is Frame.Text -> {
                                    handleJsonMessage(this, frame.readText())
                                }
                                else -> {}
                            }
                        }
                    } catch (e: ClosedReceiveChannelException) {
                        Log.i(TAG, "Session closed cleanly: $sessionId")
                    } catch (e: Throwable) {
                        Log.e(TAG, "Session error in $sessionId: ${e.message}")
                    } finally {
                        activeSessions.remove(sessionId)
                        Log.i(TAG, "Session removed: $sessionId. Remaining: ${activeSessions.size}")
                    }
                }
            }
        }.start(wait = false)

        Log.i(TAG, "Ktor Server successfully listening on port $port")
    }

    private fun handleBinaryTouchPacket(bytes: ByteArray) {
        if (bytes.size < 10) return
        val buffer = ByteBuffer.wrap(bytes)
        val opcode = buffer.get().toInt() and 0xFF
        val pointerId = buffer.get().toInt() and 0xFF
        val rawX = buffer.short.toInt() and 0xFFFF
        val rawY = buffer.short.toInt() and 0xFFFF
        val timestamp = buffer.int.toLong()

        val normX = rawX / 65535.0f
        val normY = rawY / 65535.0f

        touchManager.ingestTouch(opcode, pointerId, normX, normY, timestamp)
    }

    private suspend fun handleJsonMessage(session: WebSocketSession, text: String) {
        try {
            val json = JSONObject(text)
            val op = json.optInt("op", -1)

            when (op) {
                0x22 -> { // SYNC_REQUEST
                    val fullSync = JSONObject().apply {
                        put("op", 0x21)
                        put("state", getInitialStateJson())
                    }
                    session.send(Frame.Text(fullSync.toString()))
                }
                0x40 -> { // HEARTBEAT
                    val ack = JSONObject().apply {
                        put("op", 0x41)
                        put("ts", json.optLong("ts"))
                        put("serverTs", System.currentTimeMillis())
                    }
                    session.send(Frame.Text(ack.toString()))
                }
                0x31 -> { // ADMIN_COMMAND from client (e.g. settings theme or animation duration)
                    val cmd = json.optString("cmd")
                    if (cmd == "toggle_touch") {
                        adminConfig.touchInputEnabled = json.optBoolean("enabled", true)
                        broadcastAdminConfig()
                    } else if (cmd == "set_theme") {
                        adminConfig.theme = json.optString("theme", "macos")
                        broadcastAdminConfig()
                    } else if (cmd == "set_animation_duration") {
                        adminConfig.animationDurationMs = json.optInt("duration", 300)
                        broadcastAdminConfig()
                    } else if (cmd == "set_audio_route") {
                        adminConfig.audioRoute = json.optString("route", "receiver")
                        broadcastAdminConfig()
                    } else if (cmd == "set_brightness") {
                        adminConfig.brightness = json.optInt("brightness", 100)
                        broadcastAdminConfig()
                    } else if (cmd == "set_dark_mode") {
                        adminConfig.darkMode = json.optBoolean("darkMode", true)
                        broadcastAdminConfig()
                    } else if (cmd == "set_custom_icon") {
                        val iconId = json.optString("iconId")
                        val svg = json.optString("svg")
                        if (iconId.isNotEmpty() && svg.isNotEmpty()) {
                            adminConfig.customIcons[iconId] = svg
                            broadcastAdminConfig()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "JSON parse error from client: ${e.message}")
        }
    }

    private fun getInitialStateJson(): JSONObject {
        return JSONObject().apply {
            put("adminConfig", adminConfig.toJson())
            put("windows", JSONObject())
            put("notifications", org.json.JSONArray().apply {
                put(JSONObject().apply {
                    put("id", "n-host")
                    put("title", "Android Host Online")
                    put("body", "Ktor server-authoritative engine active.")
                    put("time", "Now")
                })
            })
            put("quickPanel", JSONObject().apply {
                put("wifi", true)
                put("bluetooth", true)
                put("volume", 85)
                put("brightness", 100)
                put("darkMode", true)
            })
            put("systemStats", JSONObject().apply {
                put("cpu", 10)
                put("ram", "2.1 / 8.0 GB")
                put("temp", 35)
                put("battery", 95)
            })
        }
    }

    fun broadcastAdminConfig() {
        val payload = JSONObject().apply {
            put("op", 0x30) // ADMIN_CONFIG
            put("config", adminConfig.toJson())
        }.toString()

        serverScope.launch {
            for ((_, session) in activeSessions) {
                try {
                    session.send(Frame.Text(payload))
                } catch (ignored: Exception) {}
            }
        }
    }

    private suspend fun serveAsset(call: ApplicationCall, assetPath: String, defaultMime: String) {
        try {
            // First look in app assets folder
            context.assets.open("omnios/$assetPath").use { inputStream ->
                val bytes = inputStream.readBytes()
                call.respondBytes(bytes, ContentType.parse(defaultMime))
            }
        } catch (e: Exception) {
            // Fallback to SDCard or internal storage sandbox
            val localFile = File(context.filesDir, "omnios/$assetPath")
            if (localFile.exists()) {
                call.respondFile(localFile)
            } else {
                call.respond(HttpStatusCode.NotFound, "Asset not found: $assetPath")
            }
        }
    }

    private fun getMimeType(path: String): String {
        return when {
            path.endsWith(".svg") -> "image/svg+xml"
            path.endsWith(".png") -> "image/png"
            path.endsWith(".jpg") -> "image/jpeg"
            path.endsWith(".mp4") -> "video/mp4"
            path.endsWith(".mp3") -> "audio/mpeg"
            path.endsWith(".pdf") -> "application/pdf"
            path.endsWith(".woff2") -> "font/woff2"
            else -> "application/octet-stream"
        }
    }

    fun stop() {
        serverEngine?.stop(1000, 2000)
        activeSessions.clear()
        serverScope.cancel()
        Log.i(TAG, "Ktor Server stopped.")
    }
}
