package com.omnios.v2.host.receiver

import android.media.MediaCodec
import android.media.MediaFormat
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer

/**
 * OmniOS v2 - Hardware-Accelerated H.264 Receiver Video Decoder
 * Feeds received NAL units directly into Android MediaCodec rendering onto SurfaceView.
 */
class NativeVideoDecoder(
    private val targetSurface: Surface,
    private val width: Int = 1920,
    private val height: Int = 1080
) {
    companion object {
        private const val TAG = "OmniOS:VideoDecoder"
        private const val MIME_TYPE = MediaFormat.MIMETYPE_VIDEO_AVC
    }

    private var decoder: MediaCodec? = null
    private var isConfigured = false

    fun initDecoder(spsPpsBuffer: ByteArray? = null) {
        try {
            val format = MediaFormat.createVideoFormat(MIME_TYPE, width, height)
            if (spsPpsBuffer != null) {
                format.setByteBuffer("csd-0", ByteBuffer.wrap(spsPpsBuffer))
            }

            decoder = MediaCodec.createDecoderByType(MIME_TYPE).apply {
                configure(format, targetSurface, null, 0)
                start()
            }
            isConfigured = true
            Log.i(TAG, "Native H.264 Video Decoder initialized successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize video decoder: ${e.message}", e)
        }
    }

    fun feedEncodedFrame(frameData: ByteArray, timestampUs: Long) {
        if (!isConfigured) return
        val codec = decoder ?: return

        try {
            val inIndex = codec.dequeueInputBuffer(10_000)
            if (inIndex >= 0) {
                val inBuffer = codec.getInputBuffer(inIndex)
                inBuffer?.clear()
                inBuffer?.put(frameData)
                codec.queueInputBuffer(inIndex, 0, frameData.size, timestampUs, 0)
            }

            val info = MediaCodec.BufferInfo()
            var outIndex = codec.dequeueOutputBuffer(info, 0)
            while (outIndex >= 0) {
                // Render directly onto SurfaceView with hardware zero-copy
                codec.releaseOutputBuffer(outIndex, true)
                outIndex = codec.dequeueOutputBuffer(info, 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Frame decode error: ${e.message}")
        }
    }

    fun release() {
        isConfigured = false
        try {
            decoder?.stop()
            decoder?.release()
        } catch (ignored: Exception) {}
        decoder = null
        Log.i(TAG, "Video decoder released.")
    }
}
