package com.omnios.v2.host.receiver

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log

/**
 * OmniOS v2 - Low-Latency PCM Audio Player for Receiver Mode
 * Plays streamed audio frames received from the Host Phone on local tablet/phone speakers.
 */
class NativeAudioPlayer(
    private val sampleRate: Int = 44100
) {
    companion object {
        private const val TAG = "OmniOS:AudioPlayer"
    }

    private var audioTrack: AudioTrack? = null
    private var isPlaying = false

    fun start() {
        if (isPlaying) return

        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(minBufferSize * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
            isPlaying = true
            Log.i(TAG, "AudioTrack playback engine started at $sampleRate Hz.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start AudioTrack: ${e.message}", e)
        }
    }

    fun playChunk(pcmBytes: ByteArray) {
        if (!isPlaying || audioTrack == null) return
        audioTrack?.write(pcmBytes, 0, pcmBytes.size)
    }

    fun stop() {
        isPlaying = false
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (ignored: Exception) {}
        audioTrack = null
        Log.i(TAG, "AudioTrack stopped.")
    }
}
