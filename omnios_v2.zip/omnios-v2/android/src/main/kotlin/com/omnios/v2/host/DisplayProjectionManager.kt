package com.omnios.v2.host

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.io.IOException
import java.nio.ByteBuffer

/**
 * OmniOS v2 - Wireless Display & Hardware Accelerated Projection Manager
 * Encodes desktop or headless VirtualDisplay into H.264 NAL units for casting
 * with sub-30ms glass-to-glass latency.
 */
class DisplayProjectionManager(
    private val context: Context,
    var width: Int = 1920,
    var height: Int = 1080,
    var targetBitrate: Int = 8_000_000, // 8 Mbps
    var frameRate: Int = 60
) {
    companion object {
        private const val TAG = "OmniOS:Projection"
        private const val MIME_TYPE = MediaFormat.MIMETYPE_VIDEO_AVC // H.264
    }

    private var mediaCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var encoderThread: HandlerThread? = null
    private var encoderHandler: Handler? = null
    private var isStreaming = false

    var onEncodedPacketListener: ((packet: ByteArray, isKeyFrame: Boolean, timestampUs: Long) -> Unit)? = null

    fun startHeadlessVirtualDisplay(mediaProjection: MediaProjection? = null) {
        if (isStreaming) return
        Log.i(TAG, "Starting hardware encoder for wireless casting: ${width}x${height} @ ${frameRate}fps")

        encoderThread = HandlerThread("OmniOS:VideoEncoder").apply { start() }
        encoderHandler = Handler(encoderThread!!.looper)

        try {
            setupMediaCodec()
            if (mediaProjection != null) {
                virtualDisplay = mediaProjection.createVirtualDisplay(
                    "OmniOS-VirtualDisplay",
                    width, height, 320,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION,
                    inputSurface, null, null
                )
            }
            isStreaming = true
            drainEncoderAsync()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start projection encoder: ${e.message}", e)
            stop()
        }
    }

    private fun setupMediaCodec() {
        val format = MediaFormat.createVideoFormat(MIME_TYPE, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, targetBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 second keyframe interval
            // Ultra-low latency tuning
            setInteger(MediaFormat.KEY_LATENCY, 0)
            setInteger(MediaFormat.KEY_PRIORITY, 0) // Realtime priority
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0) // Zero B-frames for zero reordering latency
            }
        }

        mediaCodec = MediaCodec.createEncoderByType(MIME_TYPE).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = createInputSurface()
            start()
        }
    }

    private fun drainEncoderAsync() {
        encoderHandler?.post(object : Runnable {
            override fun run() {
                val codec = mediaCodec ?: return
                if (!isStreaming) return

                val bufferInfo = MediaCodec.BufferInfo()
                try {
                    var outputIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                    while (outputIndex >= 0) {
                        val outputBuffer = codec.getOutputBuffer(outputIndex)
                        if (outputBuffer != null && bufferInfo.size > 0) {
                            outputBuffer.position(bufferInfo.offset)
                            outputBuffer.limit(bufferInfo.offset + bufferInfo.size)

                            val packet = ByteArray(bufferInfo.size)
                            outputBuffer.get(packet)

                            val isKeyFrame = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                            onEncodedPacketListener?.invoke(packet, isKeyFrame, bufferInfo.presentationTimeUs)
                        }

                        codec.releaseOutputBuffer(outputIndex, false)
                        outputIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Encoder drain cycle warning: ${e.message}")
                }

                if (isStreaming) {
                    encoderHandler?.postDelayed(this, 1000L / frameRate)
                }
            }
        })
    }

    fun requestKeyFrame() {
        mediaCodec?.let { codec ->
            val params = android.os.Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            }
            codec.setParameters(params)
        }
    }

    fun adjustBitrate(newBitrate: Int) {
        targetBitrate = newBitrate
        mediaCodec?.let { codec ->
            val params = android.os.Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, newBitrate)
            }
            codec.setParameters(params)
        }
    }

    fun stop() {
        isStreaming = false
        virtualDisplay?.release()
        virtualDisplay = null

        inputSurface?.release()
        inputSurface = null

        try {
            mediaCodec?.stop()
            mediaCodec?.release()
        } catch (ignored: Exception) {}
        mediaCodec = null

        encoderThread?.quitSafely()
        encoderThread = null
        encoderHandler = null
        Log.i(TAG, "Projection Manager stopped.")
    }
}
