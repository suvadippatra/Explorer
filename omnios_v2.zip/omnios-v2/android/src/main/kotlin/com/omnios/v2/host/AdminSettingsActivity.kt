package com.omnios.v2.host

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.omnios.v2.host.receiver.ReceiverModeActivity

/**
 * OmniOS v2 - Host Admin Settings & Control Console
 * Allows device owner to configure touch gates, available apps, audio routing,
 * display brightness, and toggle between Host and Receiver roles.
 */
class AdminSettingsActivity : Activity() {

    private lateinit var adminConfig: AdminConfig
    private lateinit var touchSwitch: Switch
    private lateinit var darkModeSwitch: Switch
    private lateinit var animSeekBar: SeekBar
    private lateinit var animValueText: TextView
    private lateinit var brightnessSeekBar: SeekBar
    private lateinit var brightnessValueText: TextView
    private lateinit var audioRadioGroup: RadioGroup
    private lateinit var btnSave: Button
    private lateinit var btnToggleService: Button
    private lateinit var btnLaunchReceiver: Button

    // Checkboxes for app gating
    private val appCheckboxes = mutableMapOf<String, CheckBox>()
    // Checkboxes for client settings visibility
    private val visCheckboxes = mutableMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load config from prefs or active service
        adminConfig = OmniOSHostService.instance?.adminConfig ?: AdminConfig.load(this)

        val scrollView = android.widget.ScrollView(this)
        val rootLayout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(36, 48, 36, 64)
        }
        scrollView.addView(rootLayout)
        setContentView(scrollView)

        // 1. Header
        val header = TextView(this).apply {
            text = "OmniOS v2 Host Admin Console"
            textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF007AFF.toInt())
            setPadding(0, 0, 0, 8)
        }
        rootLayout.addView(header)

        val subheader = TextView(this).apply {
            text = "Authoritative governance for Web Clients, Wireless Displays & Tablet Receivers."
            textSize = 13f
            setTextColor(0xFF8E8E93.toInt())
            setPadding(0, 0, 0, 24)
        }
        rootLayout.addView(subheader)

        // 2. Touch Gate Switch
        touchSwitch = Switch(this).apply {
            text = "Allow Touch Input on Web / Wireless Display"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            isChecked = adminConfig.touchInputEnabled
            setPadding(0, 8, 0, 16)
            setOnCheckedChangeListener { _, isChecked ->
                adminConfig.touchInputEnabled = isChecked
                OmniOSHostService.instance?.let { service ->
                    service.adminConfig.touchInputEnabled = isChecked
                    AdminConfig.save(this@AdminSettingsActivity, service.adminConfig)
                    service.startService(Intent(this@AdminSettingsActivity, OmniOSHostService::class.java).apply {
                        action = OmniOSHostService.ACTION_TOGGLE_TOUCH
                        putExtra("touch_enabled", isChecked)
                    })
                }
                Toast.makeText(this@AdminSettingsActivity, "Touch gate: ${if (isChecked) "ENABLED" else "DISABLED"}", Toast.LENGTH_SHORT).show()
            }
        }
        rootLayout.addView(touchSwitch)

        // 3. Audio Destination Output Selector
        val audioLabel = TextView(this).apply {
            text = "Audio Output Route:"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 16, 0, 8)
        }
        rootLayout.addView(audioLabel)

        audioRadioGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }

        val rbReceiver = RadioButton(this).apply {
            text = "🔊 Casting Receiver Device (Web Browser / Tablet Screen)"
            isChecked = adminConfig.audioRoute == "receiver"
            id = 1001
        }
        val rbHost = RadioButton(this).apply {
            text = "📱 Host Phone Speaker (Play locally on this phone)"
            isChecked = adminConfig.audioRoute == "host"
            id = 1002
        }
        val rbBoth = RadioButton(this).apply {
            text = "🎧 Both Devices (Simultaneous Dual Playback)"
            isChecked = adminConfig.audioRoute == "both"
            id = 1003
        }

        audioRadioGroup.addView(rbReceiver)
        audioRadioGroup.addView(rbHost)
        audioRadioGroup.addView(rbBoth)
        rootLayout.addView(audioRadioGroup)

        // 4. Display Brightness Calibration
        brightnessValueText = TextView(this).apply {
            text = "Display Luminance / Brightness: ${adminConfig.brightness}%"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 20, 0, 6)
        }
        rootLayout.addView(brightnessValueText)

        brightnessSeekBar = SeekBar(this).apply {
            max = 85
            progress = adminConfig.brightness - 15
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                    val b = prog + 15
                    adminConfig.brightness = b
                    brightnessValueText.text = "Display Luminance / Brightness: $b%"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        rootLayout.addView(brightnessSeekBar)

        // 5. Dark Mode Toggle
        darkModeSwitch = Switch(this).apply {
            text = "Global Dark Mode Theme"
            textSize = 14f
            isChecked = adminConfig.darkMode
            setPadding(0, 12, 0, 16)
            setOnCheckedChangeListener { _, isChecked ->
                adminConfig.darkMode = isChecked
            }
        }
        rootLayout.addView(darkModeSwitch)

        // 6. Section: Allowed Applications
        val appsLabel = TextView(this).apply {
            text = "Host-Authorized Applications:"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 16, 0, 8)
        }
        rootLayout.addView(appsLabel)

        val allApps = listOf(
            "files" to "File Manager (Host Sandboxed)",
            "video" to "Hardware Video Player",
            "music" to "Audio Player Engine",
            "pdf" to "PDF Document Reader",
            "notes" to "Text / Code Editor",
            "terminal" to "Server Terminal",
            "sysmon" to "System Diagnostics",
            "settings" to "Client System Settings"
        )

        allApps.forEach { (id, label) ->
            val cb = CheckBox(this).apply {
                text = label
                isChecked = adminConfig.allowedApps.contains(id)
            }
            appCheckboxes[id] = cb
            rootLayout.addView(cb)
        }

        // 7. Section: Client Settings Visibility
        val visLabel = TextView(this).apply {
            text = "Settings Visible on Client OS:"
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 20, 0, 8)
        }
        rootLayout.addView(visLabel)

        val allVis = listOf(
            "appearance" to "Theme / Wallpaper Settings",
            "animation" to "Animation Duration Sliders",
            "sound" to "Sound & Volume Controls",
            "storage" to "Storage Diagnostics",
            "host" to "Host Connection Diagnostics"
        )

        allVis.forEach { (id, label) ->
            val cb = CheckBox(this).apply {
                text = label
                isChecked = adminConfig.settingsVisibility[id] ?: true
            }
            visCheckboxes[id] = cb
            rootLayout.addView(cb)
        }

        // 8. Section: Animation Speed
        animValueText = TextView(this).apply {
            text = "Animation Duration: ${adminConfig.animationDurationMs} ms"
            textSize = 14f
            setPadding(0, 20, 0, 6)
        }
        rootLayout.addView(animValueText)

        animSeekBar = SeekBar(this).apply {
            max = 700
            progress = adminConfig.animationDurationMs - 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                    val duration = prog + 100
                    adminConfig.animationDurationMs = duration
                    animValueText.text = "Animation Duration: $duration ms"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        rootLayout.addView(animSeekBar)

        // 9. Buttons
        btnSave = Button(this).apply {
            text = "Apply Policies to Live Clients"
            setBackgroundColor(0xFF007AFF.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 20, 0, 20)
            setOnClickListener {
                applyAdminChanges()
            }
        }
        rootLayout.addView(android.widget.Space(this).apply { minimumHeight = 28 })
        rootLayout.addView(btnSave)

        btnToggleService = Button(this).apply {
            text = if (OmniOSHostService.instance != null) "Stop Host Server" else "Start Host Server"
            setOnClickListener {
                if (OmniOSHostService.instance != null) {
                    stopService(Intent(this@AdminSettingsActivity, OmniOSHostService::class.java))
                    text = "Start Host Server"
                    Toast.makeText(this@AdminSettingsActivity, "Host Server Stopped", Toast.LENGTH_SHORT).show()
                } else {
                    startService(Intent(this@AdminSettingsActivity, OmniOSHostService::class.java).apply {
                        action = OmniOSHostService.ACTION_START
                    })
                    text = "Stop Host Server"
                    Toast.makeText(this@AdminSettingsActivity, "Host Server Started", Toast.LENGTH_SHORT).show()
                }
            }
        }
        rootLayout.addView(android.widget.Space(this).apply { minimumHeight = 14 })
        rootLayout.addView(btnToggleService)

        // 10. Switch to Receiver Mode (App-to-App Modality)
        btnLaunchReceiver = Button(this).apply {
            text = "Launch as Receiver Screen (For Tablets / Secondary Phones)"
            setBackgroundColor(0xFF34C759.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                val intent = Intent(this@AdminSettingsActivity, ReceiverModeActivity::class.java)
                startActivity(intent)
            }
        }
        rootLayout.addView(android.widget.Space(this).apply { minimumHeight = 14 })
        rootLayout.addView(btnLaunchReceiver)
    }

    private fun applyAdminChanges() {
        // Collect audio route
        when (audioRadioGroup.checkedRadioButtonId) {
            1001 -> adminConfig.audioRoute = "receiver"
            1002 -> adminConfig.audioRoute = "host"
            1003 -> adminConfig.audioRoute = "both"
        }

        // Collect apps
        adminConfig.allowedApps.clear()
        appCheckboxes.forEach { (id, cb) ->
            if (cb.isChecked) adminConfig.allowedApps.add(id)
        }

        // Collect visibility
        visCheckboxes.forEach { (id, cb) ->
            adminConfig.settingsVisibility[id] = cb.isChecked
        }

        // Save to prefs
        AdminConfig.save(this, adminConfig)

        // Sync with live running service
        OmniOSHostService.instance?.let { service ->
            service.adminConfig.audioRoute = adminConfig.audioRoute
            service.adminConfig.brightness = adminConfig.brightness
            service.adminConfig.darkMode = adminConfig.darkMode
            service.adminConfig.allowedApps = adminConfig.allowedApps
            service.adminConfig.settingsVisibility = adminConfig.settingsVisibility
            service.adminConfig.animationDurationMs = adminConfig.animationDurationMs
            service.adminConfig.touchInputEnabled = adminConfig.touchInputEnabled
        }

        Toast.makeText(this, "Admin policies applied & broadcasted to clients!", Toast.LENGTH_LONG).show()
    }
}
