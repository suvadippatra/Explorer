/**
 * OmniOS v2 - Host Admin Control Interface
 * Exposes REST & WebSocket control channels for the Android host app
 * to configure permissions, toggle wireless display touch, and restrict settings.
 */

function setupAdminApi(app, stateEngine) {
  // 1. Host Status
  app.get('/api/admin/status', (req, res) => {
    res.json({
      success: true,
      engine: 'OmniOS v2 Server-Authoritative SDUI',
      host: 'Android Ktor / Node Reference',
      config: stateEngine.state.adminConfig,
      stats: stateEngine.state.systemStats,
      activeWindows: Object.keys(stateEngine.state.windows).length
    });
  });

  // 2. Touch Input Gate Control
  app.post('/api/admin/touch', (req, res) => {
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ error: 'Field "enabled" (boolean) required' });
    }
    stateEngine.setTouchInputEnabled(enabled);
    res.json({ success: true, touchInputEnabled: stateEngine.state.adminConfig.touchInputEnabled });
  });

  // 3. Allowed Apps Control
  app.post('/api/admin/apps', (req, res) => {
    const { apps } = req.body || {};
    if (!Array.isArray(apps)) {
      return res.status(400).json({ error: 'Field "apps" (array) required' });
    }
    stateEngine.setAllowedApps(apps);
    res.json({ success: true, allowedApps: stateEngine.state.adminConfig.allowedApps });
  });

  // 4. Settings Visibility Toggle
  app.post('/api/admin/settings-visibility', (req, res) => {
    const { visibility } = req.body || {};
    if (!visibility || typeof visibility !== 'object') {
      return res.status(400).json({ error: 'Field "visibility" (object) required' });
    }
    stateEngine.setSettingsVisibility(visibility);
    res.json({ success: true, settingsVisibility: stateEngine.state.adminConfig.settingsVisibility });
  });

  // 5. Update Sandbox Files
  app.post('/api/admin/files', (req, res) => {
    const { files, path } = req.body || {};
    if (path) {
      stateEngine.state.adminConfig.fileSandboxPath = path;
    }
    if (Array.isArray(files)) {
      stateEngine.setSandboxFiles(files);
    }
    res.json({ success: true, count: stateEngine.state.files.length });
  });

  // 6. Push System Notification from Host
  app.post('/api/admin/notify', (req, res) => {
    const { title, body } = req.body || {};
    if (!title || !body) {
      return res.status(400).json({ error: 'Title and body required' });
    }
    stateEngine.pushNotification(title, body);
    res.json({ success: true });
  });

  // 7. Audio Output Route Control (Host, Receiver, Both)
  app.post('/api/admin/audio-route', (req, res) => {
    const { route } = req.body || {};
    if (!['receiver', 'host', 'both'].includes(route)) {
      return res.status(400).json({ error: 'Route must be "receiver", "host", or "both"' });
    }
    stateEngine.setAudioRoute(route);
    res.json({ success: true, audioRoute: stateEngine.state.adminConfig.audioRoute });
  });

  // 8. Software Luminance Display Brightness
  app.post('/api/admin/brightness', (req, res) => {
    const { brightness } = req.body || {};
    const val = parseInt(brightness, 10);
    if (isNaN(val)) {
      return res.status(400).json({ error: 'Valid integer "brightness" (15-100) required' });
    }
    stateEngine.setBrightness(val);
    res.json({ success: true, brightness: stateEngine.state.adminConfig.brightness });
  });

  // 9. Dark Mode Theme Toggle
  app.post('/api/admin/dark-mode', (req, res) => {
    const { darkMode } = req.body || {};
    if (typeof darkMode !== 'boolean') {
      return res.status(400).json({ error: 'Field "darkMode" (boolean) required' });
    }
    stateEngine.setDarkMode(darkMode);
    res.json({ success: true, darkMode: stateEngine.state.adminConfig.darkMode });
  });

  // 10. Dynamic Icon Upload & Override
  app.post('/api/admin/icons', (req, res) => {
    const { icons } = req.body || {};
    if (!icons || typeof icons !== 'object') {
      return res.status(400).json({ error: 'Object "icons" { [id]: svgString } required' });
    }
    for (const [id, svg] of Object.entries(icons)) {
      stateEngine.setCustomIcon(id, svg);
    }
    res.json({ success: true, count: Object.keys(stateEngine.state.adminConfig.customIcons).length });
  });
}

module.exports = { setupAdminApi };

