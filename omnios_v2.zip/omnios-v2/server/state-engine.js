/**
 * OmniOS v2 - Server-Authoritative State Engine
 * Owns all operating system execution, window geometry, app processes,
 * sandboxed file system, and host admin policy enforcement.
 * Equivalent to the Kotlin StateEngine inside Android Host App.
 */

const EventEmitter = require('events');

class StateEngine extends EventEmitter {
  constructor() {
    super();

    this.windowCounter = 1;
    this.topZIndex = 100;

    // Authoritative State
    this.state = {
      windows: {},
      activeWindowId: null,
      adminConfig: {
        touchInputEnabled: true,
        audioRoute: 'receiver', // 'receiver' (web/cast), 'host' (phone speaker), 'both'
        brightness: 100,
        darkMode: true,
        allowedApps: ['files', 'video', 'music', 'pdf', 'notes', 'terminal', 'sysmon', 'settings'],
        settingsVisibility: {
          appearance: true,
          animation: true,
          sound: true,
          storage: true,
          host: true
        },
        theme: 'macos',
        animationDuration: 300,
        fileSandboxPath: '/sdcard/OmniOS/Sandbox',
        customIcons: {}
      },
      files: [
        { name: 'Documents', type: 'folder', size: '4 items' },
        { name: 'Media', type: 'folder', size: '12 items' },
        { name: 'welcome_v2.txt', type: 'file', ext: 'txt', size: '2.4 KB' },
        { name: 'presentation_sample.mp4', type: 'file', ext: 'mp4', size: '18.5 MB' },
        { name: 'ambient_theme.mp3', type: 'file', ext: 'mp3', size: '4.2 MB' },
        { name: 'system_architecture.pdf', type: 'file', ext: 'pdf', size: '1.1 MB' }
      ],
      notifications: [
        { id: 'n1', title: 'OmniOS Host Online', body: 'Android server authoritative session active.', time: '10:00 AM' },
        { id: 'n2', title: 'Touch Engine Calibrated', body: 'Rate-independent touch sampling ready at 60Hz.', time: '10:02 AM' }
      ],
      quickPanel: {
        wifi: true,
        bluetooth: true,
        volume: 80,
        brightness: 100,
        darkMode: true
      },
      systemStats: {
        cpu: 14,
        ram: '2.3 / 8.0 GB',
        temp: 36,
        battery: 92
      }
    };

    // App Registry metadata
    this.appRegistry = {
      files: { title: 'File Manager', w: 680, h: 460 },
      video: { title: 'Hardware Video Player', w: 720, h: 480 },
      music: { title: 'High-Res Audio Player', w: 420, h: 400 },
      pdf: { title: 'PDF Document Reader', w: 640, h: 560 },
      notes: { title: 'Text Editor', w: 580, h: 440 },
      terminal: { title: 'Host Terminal', w: 600, h: 380 },
      sysmon: { title: 'Host System Diagnostics', w: 560, h: 420 },
      settings: { title: 'System Settings', w: 540, h: 460 }
    };

    this.startSystemMetricsLoop();
  }

  startSystemMetricsLoop() {
    setInterval(() => {
      // Simulate slight variation in CPU & temperature
      const deltaCpu = Math.floor(Math.random() * 7) - 3;
      this.state.systemStats.cpu = Math.max(5, Math.min(85, this.state.systemStats.cpu + deltaCpu));

      this.emitDelta([
        {
          type: 'update',
          entity: 'systemStats',
          data: this.state.systemStats
        }
      ]);
    }, 4000);
  }

  emitDelta(patches) {
    this.emit('delta', patches);
  }

  getFullSyncState() {
    return {
      windows: this.state.windows,
      adminConfig: this.state.adminConfig,
      notifications: this.state.notifications,
      quickPanel: this.state.quickPanel,
      systemStats: this.state.systemStats
    };
  }

  /* ==========================================================================
     Window Management (Server-Authoritative)
     ========================================================================== */

  openApp(appId, customData = {}) {
    // Check if app is allowed by Admin
    if (!this.state.adminConfig.allowedApps.includes(appId)) {
      console.warn(`[StateEngine] App ${appId} launch denied by Admin policy.`);
      this.pushNotification('App Blocked', `Launch of ${appId} is restricted by Host Admin.`);
      return null;
    }

    // Check if instance already exists
    const existing = Object.entries(this.state.windows).find(([id, w]) => w.appId === appId);
    if (existing) {
      this.focusWindow(existing[0]);
      if (existing[1].isMinimized) {
        this.restoreWindow(existing[0]);
      }
      return existing[0];
    }

    const reg = this.appRegistry[appId] || { title: appId, w: 560, h: 400 };
    const winId = `win-${this.windowCounter++}`;
    const screenW = 1280;
    const screenH = 800;

    // Cascade position
    const offset = (this.windowCounter % 8) * 28;
    const initialX = Math.max(40, (screenW - reg.w) / 2 + offset);
    const initialY = Math.max(50, (screenH - reg.h) / 2 - 40 + offset);

    let initialAppData = { ...customData };
    if (appId === 'files') {
      initialAppData.files = this.state.files;
      initialAppData.currentPath = this.state.adminConfig.fileSandboxPath;
    }

    const windowObj = {
      id: winId,
      appId,
      title: reg.title,
      x: initialX,
      y: initialY,
      width: reg.w,
      height: reg.h,
      zIndex: ++this.topZIndex,
      isMinimized: false,
      isMaximized: false,
      isFocused: true,
      needsContentRefresh: true,
      appData: initialAppData
    };

    // Unfocus existing windows
    for (const w of Object.values(this.state.windows)) {
      w.isFocused = false;
    }

    this.state.windows[winId] = windowObj;
    this.state.activeWindowId = winId;

    this.emitDelta([
      {
        type: 'add',
        entity: 'window',
        id: winId,
        data: windowObj
      }
    ]);

    return winId;
  }

  closeWindow(winId) {
    if (!this.state.windows[winId]) return;
    delete this.state.windows[winId];

    if (this.state.activeWindowId === winId) {
      const remaining = Object.keys(this.state.windows);
      this.state.activeWindowId = remaining.length > 0 ? remaining[remaining.length - 1] : null;
      if (this.state.activeWindowId) {
        this.state.windows[this.state.activeWindowId].isFocused = true;
      }
    }

    this.emitDelta([
      {
        type: 'remove',
        entity: 'window',
        id: winId
      }
    ]);
  }

  minimizeWindow(winId) {
    const w = this.state.windows[winId];
    if (!w) return;
    w.isMinimized = true;
    w.isFocused = false;

    this.emitDelta([
      {
        type: 'update',
        entity: 'window',
        id: winId,
        data: { isMinimized: true, isFocused: false }
      }
    ]);
  }

  restoreWindow(winId) {
    const w = this.state.windows[winId];
    if (!w) return;
    w.isMinimized = false;
    this.focusWindow(winId);
  }

  maximizeWindow(winId) {
    const w = this.state.windows[winId];
    if (!w) return;
    w.isMaximized = !w.isMaximized;

    this.emitDelta([
      {
        type: 'update',
        entity: 'window',
        id: winId,
        data: { isMaximized: w.isMaximized }
      }
    ]);
  }

  focusWindow(winId) {
    const w = this.state.windows[winId];
    if (!w) return;

    for (const other of Object.values(this.state.windows)) {
      other.isFocused = false;
    }

    w.isFocused = true;
    w.zIndex = ++this.topZIndex;
    this.state.activeWindowId = winId;

    this.emitDelta([
      {
        type: 'update',
        entity: 'window',
        id: winId,
        data: { isFocused: true, zIndex: w.zIndex }
      }
    ]);
  }

  moveWindow(winId, x, y) {
    const w = this.state.windows[winId];
    if (!w) return;
    w.x = x;
    w.y = y;

    this.emitDelta([
      {
        type: 'update',
        entity: 'window',
        id: winId,
        data: { x, y }
      }
    ]);
  }

  resizeWindow(winId, width, height) {
    const w = this.state.windows[winId];
    if (!w) return;
    w.width = width;
    w.height = height;

    this.emitDelta([
      {
        type: 'update',
        entity: 'window',
        id: winId,
        data: { width, height }
      }
    ]);
  }

  /* ==========================================================================
     Application & Touch Interaction
     ========================================================================== */

  handleAppAction(winId, appId, action, data) {
    console.log(`[StateEngine] App action: ${appId} -> ${action}`, data);

    if (appId === 'files' && action === 'open_file') {
      const ext = data.ext;
      if (ext === 'mp4' || ext === 'mkv') {
        this.openApp('video', { videoSrc: `assets/media/${data.filename}` });
      } else if (ext === 'mp3' || ext === 'wav') {
        this.openApp('music', { currentTrack: { title: data.filename, artist: 'Host Media' } });
      } else if (ext === 'pdf') {
        this.openApp('pdf', { docName: data.filename });
      } else {
        this.openApp('notes', { content: `# File: ${data.filename}\nLoaded securely from host storage.\n` });
      }
    } else if (appId === 'notes' && action === 'save') {
      this.pushNotification('File Saved', 'Content written to host sandbox.');
    } else if (appId === 'system' && action === 'dismiss_notification') {
      this.dismissNotification(data.id);
    } else if (appId === 'system' && action === 'toggle_quick_panel') {
      const feat = data.feature;
      if (this.state.quickPanel[feat] !== undefined) {
        this.state.quickPanel[feat] = !this.state.quickPanel[feat];
        this.emitDelta([
          {
            type: 'update',
            entity: 'quickPanel',
            data: this.state.quickPanel
          }
        ]);
      }
    }
  }

  handleTouch(normX, normY, action, pointerId) {
    // Admin touch gate
    if (!this.state.adminConfig.touchInputEnabled) {
      return { ignored: true, reason: 'touch_disabled_by_admin' };
    }

    // Coordinates mapped to host virtual display
    const hostWidth = 1920;
    const hostHeight = 1080;
    const hostX = Math.round(normX * hostWidth);
    const hostY = Math.round(normY * hostHeight);

    return {
      accepted: true,
      hostX,
      hostY,
      action,
      pointerId
    };
  }

  /* ==========================================================================
     Host Admin Policy Controls
     ========================================================================== */

  setTouchInputEnabled(enabled) {
    this.state.adminConfig.touchInputEnabled = Boolean(enabled);
    console.log(`[StateEngine] Admin touch policy changed: ${this.state.adminConfig.touchInputEnabled}`);

    this.emit('admin_config_changed', this.state.adminConfig);
    this.pushNotification(
      'Touch Policy Updated',
      this.state.adminConfig.touchInputEnabled
        ? 'Touch input enabled for casting & web.'
        : 'Touch input locked by Host Admin.'
    );
  }

  setAllowedApps(appsList) {
    if (Array.isArray(appsList)) {
      this.state.adminConfig.allowedApps = appsList;
      this.emit('admin_config_changed', this.state.adminConfig);
    }
  }

  setSettingsVisibility(visibilityMap) {
    this.state.adminConfig.settingsVisibility = {
      ...this.state.adminConfig.settingsVisibility,
      ...visibilityMap
    };
    this.emit('admin_config_changed', this.state.adminConfig);
  }

  setTheme(themeName) {
    this.state.adminConfig.theme = themeName;
    this.emit('admin_config_changed', this.state.adminConfig);
  }

  setAudioRoute(route) {
    if (['receiver', 'host', 'both'].includes(route)) {
      this.state.adminConfig.audioRoute = route;
      this.emit('admin_config_changed', this.state.adminConfig);
      this.pushNotification('Audio Route Changed', `Audio output set to: ${route.toUpperCase()}`);
    }
  }

  setBrightness(brightness) {
    const val = Math.max(15, Math.min(100, parseInt(brightness, 10) || 100));
    this.state.adminConfig.brightness = val;
    this.state.quickPanel.brightness = val;
    this.emit('admin_config_changed', this.state.adminConfig);
  }

  setDarkMode(isDark) {
    this.state.adminConfig.darkMode = Boolean(isDark);
    this.state.quickPanel.darkMode = Boolean(isDark);
    this.emit('admin_config_changed', this.state.adminConfig);
  }

  setCustomIcon(iconId, svgString) {
    if (iconId && svgString) {
      this.state.adminConfig.customIcons[iconId] = svgString;
      this.emit('admin_config_changed', this.state.adminConfig);
    }
  }

  setAnimationDuration(durationMs) {
    this.state.adminConfig.animationDuration = durationMs;
    this.emit('admin_config_changed', this.state.adminConfig);
  }

  setSandboxFiles(fileList) {
    if (Array.isArray(fileList)) {
      this.state.files = fileList;
      // Refresh files app if open
      const filesWin = Object.entries(this.state.windows).find(([id, w]) => w.appId === 'files');
      if (filesWin) {
        filesWin[1].appData.files = fileList;
        filesWin[1].needsContentRefresh = true;
        this.emitDelta([
          {
            type: 'update',
            entity: 'window',
            id: filesWin[0],
            data: filesWin[1]
          }
        ]);
      }
    }
  }

  pushNotification(title, body) {
    const notif = {
      id: `n-${Date.now()}`,
      title,
      body,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    this.state.notifications.unshift(notif);
    if (this.state.notifications.length > 20) {
      this.state.notifications.pop();
    }

    this.emitDelta([
      {
        type: 'add',
        entity: 'notification',
        id: notif.id,
        data: notif
      }
    ]);
  }

  dismissNotification(id) {
    this.state.notifications = this.state.notifications.filter(n => n.id !== id);
    this.emitDelta([
      {
        type: 'remove',
        entity: 'notification',
        id
      }
    ]);
  }
}

module.exports = StateEngine;
