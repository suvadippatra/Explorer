/**
 * OmniOS v2 - Zero-Dependency Server-Authoritative Backend Engine
 * Runs on Android (Termux/Node.js) or as reference implementation for Android Ktor server.
 * Handles HTTP static assets, Admin REST API, and RFC 6455 WebSocket SDUI protocol.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const StateEngine = require('./state-engine');
const OmniOSProtocol = require('./protocol');
const { setupAdminApi } = require('./admin-api');

const PORT = process.env.PORT || 8080;
const HOST = process.env.HOST || '0.0.0.0';
const CLIENT_DIR = path.resolve(__dirname, '../client');

const stateEngine = new StateEngine();
const activeSockets = new Set();

// MIME Types map
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4',
  '.mp3': 'audio/mpeg',
  '.pdf': 'application/pdf',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf'
};

/* ==========================================================================
   HTTP Server & Admin REST Routes
   ========================================================================== */

const server = http.createServer((req, res) => {
  // CORS & Security headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // Parse URL
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // Handle Admin REST API
  if (pathname.startsWith('/api/admin')) {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      let parsedBody = {};
      if (body) {
        try { parsedBody = JSON.parse(body); } catch (e) {}
      }

      const dummyApp = {
        get: (route, handler) => {
          if (req.method === 'GET' && pathname === route) {
            handler(req, {
              json: (data) => {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(data));
              },
              status: (code) => ({
                json: (data) => {
                  res.writeHead(code, { 'Content-Type': 'application/json' });
                  res.end(JSON.stringify(data));
                }
              })
            });
          }
        },
        post: (route, handler) => {
          if (req.method === 'POST' && pathname === route) {
            req.body = parsedBody;
            handler(req, {
              json: (data) => {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(data));
              },
              status: (code) => ({
                json: (data) => {
                  res.writeHead(code, { 'Content-Type': 'application/json' });
                  res.end(JSON.stringify(data));
                }
              })
            });
          }
        }
      };

      setupAdminApi(dummyApp, stateEngine);
    });
    return;
  }

  // Static File Serving
  let relativePath = pathname === '/' ? '/index.html' : pathname;
  let safePath = path.normalize(path.join(CLIENT_DIR, relativePath));

  if (!safePath.startsWith(CLIENT_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    return res.end('Access Denied');
  }

  fs.stat(safePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for SDUI client SPA routing
      safePath = path.join(CLIENT_DIR, 'index.html');
    }

    const ext = path.extname(safePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff'
    });

    const stream = fs.createReadStream(safePath);
    stream.pipe(res);
  });
});

/* ==========================================================================
   RFC 6455 WebSocket Engine (Zero-Dependency)
   ========================================================================== */

function createWebSocketFrame(data, isBinary = false) {
  let payloadBuffer;
  if (typeof data === 'string') {
    payloadBuffer = Buffer.from(data, 'utf8');
  } else if (Buffer.isBuffer(data)) {
    payloadBuffer = data;
  } else if (data instanceof ArrayBuffer) {
    payloadBuffer = Buffer.from(data);
  } else {
    payloadBuffer = Buffer.from(JSON.stringify(data), 'utf8');
  }

  const length = payloadBuffer.length;
  let header;

  const opcode = isBinary ? 0x82 : 0x81; // FIN + Opcode

  if (length <= 125) {
    header = Buffer.alloc(2);
    header[0] = opcode;
    header[1] = length;
  } else if (length <= 65535) {
    header = Buffer.alloc(4);
    header[0] = opcode;
    header[1] = 126;
    header.writeUInt16BE(length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(length), 2);
  }

  return Buffer.concat([header, payloadBuffer]);
}

function sendToSocket(socket, message, isBinary = false) {
  if (socket && !socket.destroyed && socket.writable) {
    const frame = createWebSocketFrame(message, isBinary);
    socket.write(frame);
  }
}

function broadcast(message, isBinary = false) {
  for (const socket of activeSockets) {
    sendToSocket(socket, message, isBinary);
  }
}

// Subscribe to StateEngine delta events
stateEngine.on('delta', (patches) => {
  const json = OmniOSProtocol.packJson(OmniOSProtocol.OPCODES.STATE_DELTA, { delta: patches });
  broadcast(json, false);
});

// Subscribe to Admin Config changes
stateEngine.on('admin_config_changed', (config) => {
  const json = OmniOSProtocol.packJson(OmniOSProtocol.OPCODES.ADMIN_CONFIG, { config });
  broadcast(json, false);
});

server.on('upgrade', (req, socket, head) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (parsedUrl.pathname !== '/ws/sdui') {
    socket.destroy();
    return;
  }

  const key = req.headers['sec-websocket-key'];
  if (!key) {
    socket.destroy();
    return;
  }

  // Calculate SHA-1 digest for WebSocket handshake
  const digest = crypto
    .createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
    .digest('base64');

  const responseHeaders = [
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    `Sec-WebSocket-Accept: ${digest}`,
    '\r\n'
  ];

  socket.write(responseHeaders.join('\r\n'));
  socket.setNoDelay(true); // Disable Nagle's algorithm for sub-10ms latency

  activeSockets.add(socket);
  console.log(`[WebSocket] Client connected. Total active sessions: ${activeSockets.size}`);

  // Send initial full sync immediately
  const fullSync = OmniOSProtocol.packJson(OmniOSProtocol.OPCODES.FULL_SYNC, {
    state: stateEngine.getFullSyncState()
  });
  sendToSocket(socket, fullSync, false);

  // Incoming frame parsing buffer
  let frameBuffer = Buffer.alloc(0);

  socket.on('data', (chunk) => {
    frameBuffer = Buffer.concat([frameBuffer, chunk]);

    while (frameBuffer.length >= 2) {
      const byte0 = frameBuffer[0];
      const byte1 = frameBuffer[1];

      const fin = (byte0 & 0x80) !== 0;
      const opcode = byte0 & 0x0f;
      const isMasked = (byte1 & 0x80) !== 0;
      let payloadLength = byte1 & 0x7f;

      let offset = 2;

      if (payloadLength === 126) {
        if (frameBuffer.length < 4) break;
        payloadLength = frameBuffer.readUInt16BE(2);
        offset = 4;
      } else if (payloadLength === 127) {
        if (frameBuffer.length < 10) break;
        payloadLength = Number(frameBuffer.readBigUInt64BE(2));
        offset = 10;
      }

      const maskLength = isMasked ? 4 : 0;
      const totalFrameSize = offset + maskLength + payloadLength;

      if (frameBuffer.length < totalFrameSize) break; // Incomplete frame

      let maskingKey = null;
      if (isMasked) {
        maskingKey = frameBuffer.subarray(offset, offset + 4);
        offset += 4;
      }

      let payload = frameBuffer.subarray(offset, offset + payloadLength);
      if (isMasked && maskingKey) {
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) {
          payload[i] ^= maskingKey[i % 4];
        }
      }

      // Slice out processed frame
      frameBuffer = frameBuffer.subarray(totalFrameSize);

      // Handle Opcode
      if (opcode === 0x08) {
        // Connection Close
        socket.end();
        break;
      } else if (opcode === 0x09) {
        // Ping -> Pong
        const pong = Buffer.alloc(2);
        pong[0] = 0x8a;
        pong[1] = 0;
        socket.write(pong);
      } else if (opcode === 0x01 || opcode === 0x02) {
        // Text (0x01) or Binary (0x02)
        handleClientPayload(socket, payload, opcode === 0x02);
      }
    }
  });

  socket.on('close', () => {
    activeSockets.delete(socket);
    console.log(`[WebSocket] Client disconnected. Remaining: ${activeSockets.size}`);
  });

  socket.on('error', (err) => {
    console.warn('[WebSocket] Socket error:', err.message);
    activeSockets.delete(socket);
  });
});

/* ==========================================================================
   Incoming Client Message Processing & Touch Rate-Limiting
   ========================================================================== */

function handleClientPayload(socket, rawPayload, isBinary) {
  let msg;

  if (isBinary || (rawPayload.length === 10 && rawPayload[0] >= 0x01 && rawPayload[0] <= 0x04)) {
    // Binary touch packet
    const touch = OmniOSProtocol.decodeBinaryTouch(rawPayload.buffer.slice(rawPayload.byteOffset, rawPayload.byteOffset + rawPayload.byteLength));
    if (touch) {
      const res = stateEngine.handleTouch(touch.normX, touch.normY, touch.op, touch.pointerId);
      if (res && res.ignored) {
        // Touch was rejected by admin policy
      }
      return;
    }
  }

  // Parse JSON
  try {
    const text = rawPayload.toString('utf8');
    msg = JSON.parse(text);
  } catch (e) {
    return;
  }

  if (!msg || typeof msg.op !== 'number') return;

  switch (msg.op) {
    case OmniOSProtocol.OPCODES.SYNC_REQUEST:
      const fullSync = OmniOSProtocol.packJson(OmniOSProtocol.OPCODES.FULL_SYNC, {
        state: stateEngine.getFullSyncState()
      });
      sendToSocket(socket, fullSync, false);
      break;

    case OmniOSProtocol.OPCODES.HEARTBEAT:
      const ack = OmniOSProtocol.packJson(OmniOSProtocol.OPCODES.HEARTBEAT_ACK, {
        ts: msg.ts,
        serverTs: Date.now()
      });
      sendToSocket(socket, ack, false);
      break;

    case OmniOSProtocol.OPCODES.WINDOW_ACTION:
      handleWindowAction(msg);
      break;

    case OmniOSProtocol.OPCODES.APP_ACTION:
      stateEngine.handleAppAction(msg.winId, msg.appId, msg.action, msg);
      break;

    case OmniOSProtocol.OPCODES.ADMIN_COMMAND:
      handleAdminCommand(msg);
      break;
  }
}

function handleWindowAction(msg) {
  const { action, winId, appId, x, y, width, height } = msg;

  switch (action) {
    case 'open':
      stateEngine.openApp(appId);
      break;
    case 'close':
      stateEngine.closeWindow(winId);
      break;
    case 'minimize':
      stateEngine.minimizeWindow(winId);
      break;
    case 'maximize':
      stateEngine.maximizeWindow(winId);
      break;
    case 'restore':
      stateEngine.restoreWindow(winId);
      break;
    case 'focus':
      stateEngine.focusWindow(winId);
      break;
    case 'move':
      stateEngine.moveWindow(winId, x, y);
      break;
    case 'resize':
      stateEngine.resizeWindow(winId, width, height);
      break;
  }
}

function handleAdminCommand(msg) {
  const { cmd } = msg;
  if (cmd === 'toggle_touch') {
    stateEngine.setTouchInputEnabled(msg.enabled);
  } else if (cmd === 'set_theme') {
    stateEngine.setTheme(msg.theme);
  } else if (cmd === 'set_animation_duration') {
    stateEngine.setAnimationDuration(msg.duration);
  } else if (cmd === 'set_audio_route') {
    stateEngine.setAudioRoute(msg.route);
  } else if (cmd === 'set_brightness') {
    stateEngine.setBrightness(msg.brightness);
  } else if (cmd === 'set_dark_mode') {
    stateEngine.setDarkMode(msg.darkMode);
  } else if (cmd === 'set_custom_icon') {
    stateEngine.setCustomIcon(msg.iconId, msg.svg);
  }
}


/* ==========================================================================
   Start Server
   ========================================================================== */

server.listen(PORT, HOST, () => {
  console.log(`=======================================================`);
  console.log(`  OmniOS v2 Server-Authoritative Host Engine Started   `);
  console.log(`  Web Client URL:  http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  console.log(`  SDUI WebSocket:  ws://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}/ws/sdui`);
  console.log(`  Admin REST API:  http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}/api/admin/status`);
  console.log(`=======================================================`);
});
