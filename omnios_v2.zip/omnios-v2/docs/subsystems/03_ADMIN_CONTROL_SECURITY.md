# Subsystem 03: Host Admin Control & Security Sandboxing
### Application Gating, Settings Governance, SAF Storage Isolation & Cryptographic Pairing

---

## 1. Subsystem Overview

In OmniOS v2, the host device is authoritative over user permissions, application availability, and storage access. The client possesses no autonomous privileges.

Key capabilities:
* **Host Admin Console (`AdminSettingsActivity.kt`)**: Native Android interface allowing the administrator to toggle touch input, whitelist applications, and show or hide settings categories.
* **Storage Access Framework (SAF) Isolation**: Client applications cannot read arbitrary device directories; they are confined to a designated DocumentFile directory tree chosen by the administrator.
* **Settings Visibility Enforcement**: Granular control over which settings panels are rendered inside the client's Settings app.
* **HMAC Nonce Challenge-Response**: Cryptographically authenticates connecting clients to prevent unauthorized local network access.

---

## 2. Policy Enforcement Architecture

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              HOST ADMIN GOVERNANCE MODEL                               │
│                                                                                        │
│   ┌────────────────────────────────────────────────────────────────────────────────┐   │
│   │                     Android Host Admin Console (Activity)                      │   │
│   │                                                                                │   │
│   │   [✓] Allow Touch Input       [✓] Allowed Apps: Files, Video, Terminal         │   │
│   │   [✓] Client Settings Vis:     [✓] Appearance  [ ] Host Diagnostics (Hidden)  │   │
│   │   [✓] Storage Sandbox:        /storage/emulated/0/Documents/OmniOS/Sandbox     │   │
│   └───────────────────────────────────────┬────────────────────────────────────────┘   │
│                                           │ (Serializes into AdminConfig)              │
│                                           ▼                                            │
│   ┌────────────────────────────────────────────────────────────────────────────────┐   │
│   │                 StateEngine Policy Validator (Android Host)                    │   │
│   │                                                                                │   │
│   │   Incoming App Request: "terminal"                                             │   │
│   │   ├─ Check: adminConfig.allowedApps.contains("terminal")?                      │   │
│   │   │  ├─ TRUE  ──► Launch Window & Stream Component Tree                        │   │
│   │   │  └─ FALSE ──► Reject & Dispatch Security Warning Notification              │   │
│   │   │                                                                            │   │
│   │   Incoming Storage Request: Open "/sdcard/DCIM/private.jpg"                    │   │
│   │   └─ Check: Path starts with adminConfig.fileSandboxPath?                      │   │
│   │      └─ REJECT: 403 Forbidden (Strict Sandbox Violation)                       │   │
│   └────────────────────────────────────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Storage Sandboxing via Storage Access Framework (SAF)

To grant OmniOS access to host files without requesting dangerous all-files access (`MANAGE_EXTERNAL_STORAGE`), use Android's system document picker:

```kotlin
// In AdminSettingsActivity.kt
private val openFolderLauncher = registerForActivityResult(
    ActivityResultContracts.OpenDocumentTree()
) { uri: Uri? ->
    if (uri != null) {
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        adminConfig.fileSandboxPath = uri.toString()
        AdminConfig.save(this, adminConfig)
        Toast.makeText(this, "Sandbox directory locked to: $uri", Toast.LENGTH_SHORT).show()
    }
}

fun pickSandboxFolder() {
    openFolderLauncher.launch(null)
}
```

When the client File Manager queries directory contents, the Ktor server queries `androidx.documentfile.provider.DocumentFile` rooted at the authorized URI, guaranteeing strict operating system containment.

---

## 4. Cryptographic Pairing & Authentication

Derived from the enterprise mobile security blueprint (`mobile_to_mobile_security_mesh_webclient_deepdive.md`), OmniOS v2 supports zero-trust pairing:

1. **Host Certificate Fingerprint**: On startup, the host generates a hardware-backed EC key in Android Keystore and derives a 32-byte TLS SHA-256 fingerprint.
2. **Challenge Nonce**: When a client connects over WebSocket, the host issues:
   ```json
   {"op": 0x60, "type": "challenge", "nonce": "d8f1e94a8c..."}
   ```
3. **HMAC-SHA256 Response**: The client calculates `HMAC-SHA256(nonce, sharedSecret)` and returns the signature.
4. **Session Activation**: If verified, the server replies with `SESSION_AUTH_OK (0x61)` and dispatches `FULL_SYNC (0x21)`. Unauthenticated sessions are terminated within 3 seconds.
