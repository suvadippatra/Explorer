# Subsystem 07: Audio Output Routing & Display Luminance Calibration
### Dynamic Audio Switching, Wireless Display Brightness Shading & Vector Icon Governance

---

## 1. Audio Output Routing Subsystem

### 1.1 The Engineering Challenge
When casting an operating system from an Android phone to an external screen (web client, TV, or tablet receiver), users have conflicting audio needs:
* **Scenario A (Private / Movie Night)**: The user wants audio to play out of the big screen / tablet receiver, while the host phone remains silent.
* **Scenario B (Presentation / Walkabout)**: The user is holding the phone while showing slides on a distant screen and needs notification chimes to sound on the phone speaker.
* **Scenario C (Dual Monitoring)**: The user wants simultaneous dual playback on both the host phone and the casting receiver.

### 1.2 The Tri-Route Architecture
`AudioRoutingManager.kt` provides three dynamic targets controllable by both the Host Admin and the Client Quick Panel / Settings:

| Route Target | Host Phone Speaker | Casting Receiver (Tablet / Web) | Mechanism |
| :--- | :--- | :--- | :--- |
| **`receiver`** *(Default)* | **Muted** | **Active (16-bit PCM Stream)** | Intercepts audio via `AudioPlaybackCapture` and streams 20ms chunks over WebSocket. Host speaker is unallocated. |
| **`host`** | **Active (Local Speaker)** | **Muted** | Normal phone media routing. No audio chunks are transmitted over the network, saving bandwidth. |
| **`both`** | **Active (Local Speaker)** | **Active (16-bit PCM Stream)** | Simultaneous dual playback via local `AudioTrack` buffer and parallel network socket dispatch. |

### 1.3 Control Points
* **Host Side**: Configurable in `AdminSettingsActivity.kt` via the "Audio Output Route" radio group.
* **Client Side**: Configurable in the Quick Panel and Settings (`Sound` tab) via the 3-button selector (`🔊 Receiver`, `📱 Host`, `🎧 Both`). Changes are synchronized bidirectionally via `ADMIN_COMMAND: 'set_audio_route'`.

---

## 2. Does Display Brightness Really Work on Wireless Displays?

### 2.1 The Technical Reality
On a physical phone screen, adjusting brightness modifies the LED backlight voltage through Android's `Settings.System.SCREEN_BRIGHTNESS` or `WindowManager.LayoutParams.screenBrightness`.

However, on a **wireless display** (Smart TV via Miracast, Web Browser via WebSocket, or Tablet via App-to-App casting), **hardware backlight DDC/CI commands do not travel across standard video or network streams**. If an app only modifies `screenBrightness` on the host, the remote wireless display's brightness **does not change at all**.

### 2.2 The Solution: Software Luminance Filter
OmniOS v2 implements real-time **Software Luminance Shading**:

1. **WebClient / SDUI Stream**:
   The client engine exposes a dynamic CSS variable `--display-brightness` bound to the desktop stage:
   ```css
   #desktop {
     filter: brightness(calc(var(--display-brightness, 100) * 1%));
     transition: filter 0.2s ease-out;
   }
   ```
   When the user moves the slider from 15% to 100%, the software luminance shader darkens or brightens the entire visual feed, guaranteeing that brightness visibly dims and brightens on **any** TV, browser, or wireless monitor.

2. **Native Video Stream / Receiver Mode**:
   In `NativeVideoDecoder.kt` / `DisplayProjectionManager.kt`, an OpenGL ES fragment shader multiplies the decoded RGB frame by the luminance factor:
   ```glsl
   precision mediump float;
   uniform sampler2D u_Texture;
   uniform float u_BrightnessFactor; // 0.15 .. 1.0
   varying vec2 v_TexCoord;
   void main() {
       vec4 color = texture2D(u_Texture, v_TexCoord);
       gl_FragColor = vec4(color.rgb * u_BrightnessFactor, color.a);
   }
   ```

---

## 3. Dark Theme Mode Synchronization

* Dark mode switches `data-mode="dark"` and `data-mode="light"` across DOM elements.
* Dynamically updates background glass opacity, window titlebars, text contrast, and vector icon strokes.
* Synchronized bidirectionally between Host Admin settings and Client Quick Panel via `set_dark_mode`.

---

## 4. Theme Icon Customization & Format Reference

All icons in OmniOS are vector SVGs conforming to a `0 0 48 48` coordinate viewport.

### 4.1 Developer Editing (`client/js/icons.js`)
You can replace any icon directly in code by editing the respective OS pack (`MACOS_ICONS`, `WINDOWS_ICONS`, `LINUX_ICONS`, `DEX_ICONS`):

```javascript
// Example: Custom vector icon with gradient
files: () => svgWrap(`
  <defs>
    <linearGradient id="my_grad" x1="0" y1="0" x2="48" y2="48">
      <stop stop-color="#FF007A"/><stop offset="1" stop-color="#7928CA"/>
    </linearGradient>
  </defs>
  <rect x="2" y="2" width="44" height="44" rx="11" fill="url(#my_grad)"/>
  <path d="M14 24L22 32L36 16" stroke="#FFFFFF" stroke-width="3" stroke-linecap="round"/>
`)
```

### 4.2 Embedding Raster PNG / JPG Images
To use an existing photo or PNG logo:

```javascript
// Using Base64 Data URI (Self-contained, zero external files):
files: () => svgWrap(`
  <image href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..." width="48" height="48"/>
`)
```

### 4.3 Dynamic Admin Upload
The host admin can inject custom icon overrides via REST:
`POST /api/admin/icons` with payload:
```json
{
  "icons": {
    "system_logo": "<svg viewBox='0 0 48 48'><circle cx='24' cy='24' r='20' fill='#007AFF'/></svg>",
    "files": "<svg viewBox='0 0 48 48'><rect width='48' height='48' rx='10' fill='#FF9500'/></svg>"
  }
}
```
All connected clients immediately re-render their topbar logos, dock icons, and desktop shortcuts with the updated graphics.
