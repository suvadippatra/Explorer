# Subsystem 05: Wireless Display & Zero-Copy Hardware Projection
### Low-Latency MediaCodec H.264 Pipeline, Headless VirtualDisplay & Dual-Screen Presentation

---

## 1. Subsystem Overview

Derived from the PXS Desktop and RemotePhone hardware projection architectures (`PXS_Desktop_Complete_Rebuild_Guide.md`), this subsystem enables streaming the OmniOS desktop to wireless displays, smart TVs, external monitors, or secondary mobile devices with **glass-to-glass latency under 30 milliseconds**.

Key architecture components:
* **Headless VirtualDisplay**: Android `DisplayManager` creates an isolated display surface (`VirtualDisplay`) independent of the host phone's physical screen.
* **Zero-Copy GPU Surface Encoding**: Android's `MediaCodec` in `COLOR_FormatSurface` mode captures directly from GPU memory without CPU frame copies.
* **Low-Latency H.264 Tuning**: Zero B-frames, real-time priority, and 1-second I-frame intervals.
* **Universal Decoding**: Rendered on the client via `WebCodecs` (`VideoDecoder`) on HTML5 `<canvas>` or native Android `SurfaceView`.

---

## 2. Projection Pipeline Diagram

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              ZERO-COPY PROJECTION PIPELINE                             │
│                                                                                        │
│   ┌────────────────────────────────┐                                                   │
│   │ Android Host GPU (EGL/Vulkan)  │                                                   │
│   │ Headless VirtualDisplay Surface│                                                   │
│   └───────────────┬────────────────┘                                                   │
│                   │ (Direct Surface-to-Surface GPU texture binding)                    │
│                   ▼                                                                    │
│   ┌────────────────────────────────┐                                                   │
│   │ MediaCodec H.264 Hardware Enc  │  Format: AVC Main/Baseline, Zero B-Frames         │
│   │ COLOR_FormatSurface            │  Bitrate: 8 Mbps, 60 FPS, Realtime Priority       │
│   └───────────────┬────────────────┘                                                   │
│                   │ (H.264 NAL Units: SPS, PPS, IDR, P-Frames)                         │
│                   ▼                                                                    │
│   ┌────────────────────────────────┐                                                   │
│   │ WebSocket / WebRTC DataChannel │  Binary Frame: [0x00=Config, 0x01=Frame, Payload] │
│   └───────────────┬────────────────┘                                                   │
│                   │ (Sub-15ms Network Transit over 5GHz Wi-Fi)                         │
│                   ▼                                                                    │
│   ┌────────────────────────────────┐                                                   │
│   │ Remote Display / Client Device │  Client Decoding:                                 │
│   │ WebCodecs VideoDecoder / Canvas│  • Browser: VideoDecoder -> Canvas 2D / WebGL     │
│   │ Native Android SurfaceView     │  • Native: MediaCodec.createDecoderByType -> Surf │
│   └────────────────────────────────┘                                                   │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Hardware Video Encoder Configuration (`DisplayProjectionManager.kt`)

```kotlin
val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
    setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000) // 8 Mbps
    setInteger(MediaFormat.KEY_FRAME_RATE, 60)
    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 second keyframes
    
    // Critical Latency Reduction Flags:
    setInteger(MediaFormat.KEY_LATENCY, 0)
    setInteger(MediaFormat.KEY_PRIORITY, 0) // Realtime priority
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0) // Eliminates reordering queue
    }
}

val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
    configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
    inputSurface = createInputSurface()
    start()
}
```

---

## 4. Hardware WebCodecs Decoding on Client (`client/js/sdui-client.js`)

In client browsers supporting modern WebCodecs:

```javascript
const decoder = new VideoDecoder({
  output: (videoFrame) => {
    // Render directly to Canvas using WebGL / 2D context
    canvasCtx.drawImage(videoFrame, 0, 0, canvas.width, canvas.height);
    videoFrame.close();
  },
  error: (err) => console.error('[WebCodecs] Decode error:', err)
});

decoder.configure({
  codec: 'avc1.420028', // H.264 Baseline Profile Level 4.0
  codedWidth: 1920,
  codedHeight: 1080
});

// Incoming frame handling:
function feedFrame(nalUnitBytes, isKeyFrame, timestampUs) {
  const chunk = new EncodedVideoChunk({
    type: isKeyFrame ? 'key' : 'delta',
    timestamp: timestampUs,
    data: nalUnitBytes
  });
  decoder.decode(chunk);
}
```

---

## 5. Dual-Screen Presentation Mode (HDMI / DP Alt Mode)

When an external monitor is physically connected via USB-C DisplayPort Alternate mode, OmniOS launches a dedicated `android.app.Presentation`:

```kotlin
val displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
val externalDisplays = displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)

if (externalDisplays.isNotEmpty()) {
    val externalDisplay = externalDisplays[0]
    val presentation = object : android.app.Presentation(this, externalDisplay) {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            // Render OmniOS Desktop UI on external monitor
            setContentView(R.layout.activity_omnios_desktop)
        }
    }
    presentation.show()
}
```

This allows the user to view the full desktop on the big screen while using the phone display as an active trackpad or host admin dashboard.
