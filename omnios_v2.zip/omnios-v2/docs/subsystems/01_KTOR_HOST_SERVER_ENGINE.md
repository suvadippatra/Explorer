# Subsystem 01: Embedded Ktor Host Server Engine
### High-Concurrency HTTP & WebSocket Pipeline for Android Host Architecture

---

## 1. Subsystem Overview

The **Embedded Ktor Server Engine** serves as the primary communication bridge between the Android host application and remote rendering clients (web browsers, touch displays, or secondary mobile devices).

Key characteristics:
* **Framework**: Ktor 2.x / 3.x with Netty / CIO asynchronous coroutine engine.
* **Network Transport**: Dual HTTP/1.1 static file server and bidirectional RFC 6455 WebSocket channel (`/ws/sdui`).
* **Zero-Copy Serialization**: High-frequency telemetry packets are ingested directly as raw byte arrays without string allocations.
* **Multi-Client State Broadcasting**: Thread-safe session tracking using `ConcurrentHashMap<String, WebSocketSession>` and Kotlin Coroutine dispatchers.

---

## 2. Server Pipeline Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                                   KTOR SERVER PIPELINE                                  │
│                                                                                         │
│   ┌───────────────────┐    HTTP GET /               ┌───────────────────────────────┐   │
│   │   Remote Client   ├────────────────────────────►│ Static Asset File Provider      │   │
│   │  (Browser / TV)   │    index.html, js, css      │ (Android assets/ or filesDir) │   │
│   └─────────┬─────────┘                             └───────────────────────────────┘   │
│             │                                                                           │
│             │ Upgraded to WebSocket                                                     │
│             ▼                                                                           │
│   ┌─────────────────────────────────────────────────────────────────────────────────┐   │
│   │ /ws/sdui Routing Handler (DefaultWebSocketServerSession)                        │   │
│   │                                                                                 │   │
│   │   Frame.Binary (10 Bytes) ──────► ByteBuffer Decode ──► TouchInjectionManager  │   │
│   │   Frame.Text (JSON Command) ────► StateEngine Validation                        │   │
│   │                                                                                 │   │
│   │   ◄─── Frame.Text (FULL_SYNC / STATE_DELTA) ─────────── Differential Patches    │   │
│   └─────────────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Implementation Blueprint: Ktor Server Configuration

```kotlin
package com.omnios.v2.host

import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import java.time.Duration

fun Application.omniosModule(adminConfig: AdminConfig, touchManager: TouchInjectionManager) {
    install(WebSockets) {
        pingPeriod = Duration.ofSeconds(10)
        timeout = Duration.ofSeconds(15)
        maxFrameSize = 1024 * 1024
        masking = false
    }

    routing {
        // WebSocket SDUI & Touch Stream Endpoint
        webSocket("/ws/sdui") {
            val sessionId = System.currentTimeMillis().toString()
            try {
                // Send initial full sync
                send(Frame.Text(getInitialFullSyncJson(adminConfig)))

                for (frame in incoming) {
                    when (frame) {
                        is Frame.Binary -> {
                            val bytes = frame.readBytes()
                            if (bytes.size >= 10) {
                                val buffer = java.nio.ByteBuffer.wrap(bytes)
                                val opcode = buffer.get().toInt() and 0xFF
                                val pointerId = buffer.get().toInt() and 0xFF
                                val normX = (buffer.short.toInt() and 0xFFFF) / 65535.0f
                                val normY = (buffer.short.toInt() and 0xFFFF) / 65535.0f
                                val timestamp = buffer.int.toLong()

                                touchManager.ingestTouch(opcode, pointerId, normX, normY, timestamp)
                            }
                        }
                        is Frame.Text -> {
                            handleClientJsonMessage(frame.readText(), adminConfig)
                        }
                        else -> {}
                    }
                }
            } finally {
                // Cleanup session
            }
        }
    }
}
```

---

## 4. Android System Requirements & Dependencies

To construct this subsystem inside your Android project, declare the following dependencies in your `build.gradle.kts`:

```kotlin
dependencies {
    // Ktor Core & Netty Engine
    implementation("io.ktor:ktor-server-core:2.3.12")
    implementation("io.ktor:ktor-server-netty:2.3.12")
    implementation("io.ktor:ktor-server-websockets:2.3.12")
    implementation("io.ktor:ktor-server-content-negotiation:2.3.12")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.12")

    // Kotlin Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
```

---

## 5. Security & Authentication Safeguards

1. **Origin Verification**: The server checks the `Origin` header during WebSocket handshake to prevent Cross-Site WebSocket Hijacking (CSWSH).
2. **Token Session Validation**: When `requireAuthToken` is enabled by the Admin, incoming connections must provide a query parameter `?token=<secret>` or answer an HMAC challenge within 3 seconds of connecting.
3. **Path Traversal Protection**: Static asset file queries are verified with `safePath.startsWith(allowedDir)` to prevent accessing unauthorized private app databases or host system directories.
