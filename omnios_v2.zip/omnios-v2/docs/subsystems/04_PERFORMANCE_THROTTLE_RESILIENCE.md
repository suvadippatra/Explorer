# Subsystem 04: Anti-Throttle & Crash Resilience Engine
### High-Performance Foreground Services, Locks, Thermal Mitigation & Crash Boundaries

---

## 1. Subsystem Overview

Hosting an interactive operating system and low-latency video/touch pipeline on a mobile phone presents unique constraints:
* Android aggressive battery savers (`Doze mode`) kill background processes.
* Wi-Fi chips enter power-saving sleep cycles, spiking round-trip ping from 4ms to 350ms.
* Sustained CPU/GPU encoding can trigger hardware thermal throttling.
* Uncaught coroutine or WebSocket exceptions can crash the application.

Subsystem 04 addresses every constraint through a five-layer resilience shield.

---

## 2. The Five-Layer Resilience Shield

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                              FIVE-LAYER RESILIENCE SHIELD                              │
│                                                                                        │
│   Layer 1: Android Foreground Service Lifecycle                                        │
│   • Runs with ongoing persistent notification (Priority LOW / Ongoing)                │
│   • Returns START_STICKY to guarantee OS auto-resurrection on low-memory kills       │
│                                                                                        │
│   Layer 2: PowerManager.PARTIAL_WAKE_LOCK                                              │
│   • Prevents the CPU from sleeping even when device screen is turned off               │
│                                                                                        │
│   Layer 3: High-Performance Low-Latency WifiLock                                       │
│   • Forces Wi-Fi radio into WIFI_MODE_FULL_LOW_LATENCY (Android Q+)                   │
│   • Eliminates Wi-Fi packet aggregation delay and radio power-down pauses             │
│                                                                                        │
│   Layer 4: Thermal Throttling Mitigation                                               │
│   • Listens to PowerManager.OnThermalStatusChangedListener                             │
│   • Automatically steps frame pacing: 60fps ──► 45fps ──► 30fps to cool SoC SoC       │
│                                                                                        │
│   Layer 5: Safe Exception Boundary                                                     │
│   • Custom Thread.UncaughtExceptionHandler + CoroutineExceptionHandler                │
│   • Quarantines failed client sessions without tearing down the host daemon            │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Implementation Code Patterns

### 3.1 Lock Acquisition in `OmniOSHostService.kt`
```kotlin
private fun acquireLocks() {
    // 1. Partial WakeLock (24h timeout safety)
    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OmniOS:HostWakeLock").apply {
        setReferenceCounted(false)
        acquire(24 * 60 * 60 * 1000L)
    }

    // 2. Low-Latency WifiLock
    val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        WifiManager.WIFI_MODE_FULL_LOW_LATENCY
    } else {
        WifiManager.WIFI_MODE_FULL_HIGH_PERF
    }
    wifiLock = wm.createWifiLock(mode, "OmniOS:WifiLock").apply {
        setReferenceCounted(false)
        acquire()
    }
}
```

### 3.2 Thermal State Monitoring
```kotlin
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
    pm.addThermalStatusListener { status ->
        when (status) {
            PowerManager.THERMAL_STATUS_MODERATE -> {
                // Throttle frame pacing slightly
                displayProjectionManager.frameRate = 45
            }
            PowerManager.THERMAL_STATUS_SEVERE, PowerManager.THERMAL_STATUS_CRITICAL -> {
                // Drop to 30fps and reduce bitrate to prevent hardware shutdown
                displayProjectionManager.frameRate = 30
                displayProjectionManager.adjustBitrate(4_000_000)
            }
            PowerManager.THERMAL_STATUS_NONE -> {
                displayProjectionManager.frameRate = 60
                displayProjectionManager.adjustBitrate(8_000_000)
            }
        }
    }
}
```

### 3.3 Memory Recycling & Zero Allocation
* To avoid garbage collection (GC) pauses during 60Hz touch streaming, allocate reusable `ByteBuffer` buffers rather than instantiating new byte arrays on every frame.
* Use `ObjectPool` for WebSocket frames and `android.graphics.Path` instances.
