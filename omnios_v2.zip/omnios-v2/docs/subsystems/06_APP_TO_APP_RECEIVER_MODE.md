# Subsystem 06: App-to-App Receiver Mode & Multi-Topology Casting
### Phone-to-Tablet Projection, 4 Transport Modalities & Immersive Fullscreen Governance

---

## 1. Subsystem Overview

A key design requirement of OmniOS v2 is **multi-topology casting**: the ability to cast the desktop environment across four distinct modalities without requiring a desktop PC or cloud server.

The four supported casting modalities:
1. **Web Browser (AnyScreen)**: Zero installation. Connect via mobile or desktop Chrome/Safari.
2. **Wireless Display (Wi-Fi Direct / Miracast)**: Cast to Miracast TVs or Wi-Fi Direct peer groups.
3. **Wired Cable (USB-C DisplayPort Alt Mode / ADB Reverse)**: Zero-latency, zero-jitter wired connection over standard Type-C cable.
4. **App-to-App (Dual-Role Android APK)**: The **exact same Android app** can run in either **Host Mode** on Phone A or **Receiver Mode** on Tablet B, transforming any Android tablet into an interactive, touch-enabled wireless monitor for the phone.

---

## 2. The 4 Projection Topologies

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                               4 PROJECTION TOPOLOGIES                                  │
│                                                                                        │
│   ┌────────────────────────────────────────────────────────────────────────────────┐   │
│   │                          PHONE A (HOST DAEMON)                                 │   │
│   │   • OmniOSHostService (Foreground Service with START_STICKY)                   │   │
│   │   • Embedded Ktor Server (:8080)                                               │   │
│   │   • MediaCodec H.264 Encoder (COLOR_FormatSurface)                             │   │
│   │   • TouchInjectionManager (AccessibilityService)                               │   │
│   └──────┬──────────────────────┬──────────────────────┬──────────────────────┬────┘   │
│          │                      │                      │                      │        │
│          │ 1. HTTP/WSS          │ 2. Miracast/P2P      │ 3. Type-C DP Alt     │ 4. WSS │
│          ▼                      ▼                      ▼                      ▼        │
│   ┌──────────────┐       ┌──────────────┐       ┌──────────────┐       ┌───────────┐   │
│   │ 1. WebClient │       │ 2. Wireless  │       │ 3. Wired     │       │ 4. App-to-│   │
│   │  (Chrome /   │       │     Display  │       │     Monitor  │       │    App    │   │
│   │   Smart TV)  │       │  (Miracast / │       │  (Portable   │       │  (Tablet  │   │
│   │  • WebCodecs │       │   Wi-Fi P2P) │       │   USB-C LCD) │       │  Receiver)│   │
│   │  • SDUI DOM  │       │  • H.264     │       │  • DP Alt    │       │  • Native │   │
│   │  • Touch     │       │  • Sub-40ms  │       │  • 0ms Lag   │       │    Codec  │   │
│   └──────────────┘       └──────────────┘       └──────────────┘       └───────────┘   │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. App-to-App Architecture (Phone A Host ◄──► Tablet B Receiver)

In **App-to-App mode**, Phone A runs the intensive desktop applications (files, videos, code editor, terminal), while Tablet B acts purely as a hardware-accelerated remote display with touch forwarding:

### 3.1 Receiver Components on Tablet B:
1. **`ReceiverModeActivity.kt`**: Fullscreen native activity. Automatically acquires `WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE` and hides status/navigation bars.
2. **`NativeVideoDecoder.kt`**: Feeds H.264 NAL units received over WebSocket directly into Android's GPU hardware decoder (`MediaCodec`), displaying frames on a `SurfaceView` at 60fps with sub-15ms decode latency.
3. **`RemoteTouchView.kt`**: Multi-touch listener attached to Tablet B's screen. Normalizes $(x, y)$ touch points to $[0.0, 1.0]$ floating-point ratios and dispatches 10-byte binary packets back to Phone A.
4. **`NativeAudioPlayer.kt`**: Low-latency PCM stereo audio player feeding mirrored phone audio to Tablet B's speakers.

---

## 4. Fullscreen Button Suppression Logic

### The Problem
On a web browser running inside a windowed desktop environment, a "Fullscreen" toggle button is useful. However, when casting to a **Wireless Display** or running in **Native App Receiver Mode** on a tablet, displaying a "Toggle Fullscreen" button is redundant, confusing, and degrades UX.

### The Implementation
The SDUI engine implements smart environment detection:

```javascript
detectEnvironment() {
  const params = new URLSearchParams(window.location.search);
  const isReceiver = params.get('mode') === 'receiver' ||
                     params.get('receiver') === 'true' ||
                     params.get('cast') === 'true' ||
                     window.AndroidReceiverBridge !== undefined ||
                     window.matchMedia('(display-mode: standalone)').matches;

  if (isReceiver) {
    document.body.classList.add('receiver-mode');
  }
}
```

In `css/sdui-extra.css`, fullscreen buttons are cleanly eliminated when in receiver or cast mode:

```css
body.receiver-mode .fullscreen-toggle-btn,
body.receiver-mode #topbar-fullscreen-btn,
body.fullscreen-active .fullscreen-toggle-btn {
  display: none !important;
}
```

In `ReceiverModeActivity.kt`, the native Android window manager enforces immersive sticky fullscreen natively:

```kotlin
WindowCompat.setDecorFitsSystemWindows(window, false)
val controller = WindowInsetsControllerCompat(window, window.decorView)
controller.hide(WindowInsetsCompat.Type.systemBars())
controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
```
