# Subsystem 02: Touch Event Pipeline & Remote Gesture Injection
### Rate-Independent Telemetry, Coordinate Normalization & Android Accessibility Gesture Dispatch

---

## 1. Subsystem Overview

The **Touch Event Pipeline** delivers seamless, tactile interaction between touch-enabled wireless displays (monitors, smart TVs, tablets) and the host Android device.

Key engineering highlights:
* **Normalized Float Space**: Coordinates are normalized to $[0.0, 1.0]$, ensuring flawless mapping across arbitrary client screen resolutions and aspect ratios.
* **10-Byte Compact Binary Serialization**: Downsampled touch stream consuming $<1$ KB/sec per active pointer.
* **Client-Side Immediate Echo**: Hardware-accelerated local ripple rendering ensures perceived zero-delay tactile response before packet round-trip.
* **Adaptive Backpressure Dropping**: Avoids saturating Android's gesture queue by discarding stale move events when the previous stroke is still executing.
* **Host Admin Touch Gate**: Immediate server-side discarding of touch packets when locked by Admin.

---

## 2. Touch Ingestion & Coordinate Geometry

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                 TOUCH PIPELINE GEOMETRY                                │
│                                                                                        │
│   Touch on Wireless Display (Client)                Host Phone Screen / VirtualDisplay │
│   Resolution: 2560 x 1440                            Resolution: 1920 x 1080           │
│   Raw Touch: (1280, 720)                                                               │
│          │                                                                             │
│          ▼ [Normalize]                                                                 │
│   NormX = 1280 / 2560 = 0.5000                                                         │
│   NormY =  720 / 1440 = 0.5000                                                         │
│          │                                                                             │
│          ▼ [Pack 10B Binary]                                                           │
│   [0x02, id:0, x:32767, y:32767, ts] ──────► Network (WebSocket)                       │
│                                                     │                                  │
│                                                     ▼ [Host Unpack]                    │
│                                              NormX = 0.5000, NormY = 0.5000            │
│                                                     │                                  │
│                                                     ▼ [Map to Host Pixels]             │
│                                              HostX = 0.5000 * 1920 = 960               │
│                                              HostY = 0.5000 * 1080 = 540               │
│                                                     │                                  │
│                                                     ▼ [Inject Gesture]                 │
│                                              AccessibilityService.dispatchGesture()    │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Adaptive Backpressure & Rate Smoothing

When dragging across a wireless display, the client may emit 60 to 120 touch points per second. Android's `AccessibilityService.dispatchGesture()` operates asynchronously on the system input thread. If strokes are dispatched faster than Android completes them, the queue backs up, resulting in noticeable latency and rubber-banding.

### The Solution: Latest-Point Retain Algorithm
`TouchInjectionManager.kt` maintains an atomic flag `isDispatchingGesture`:
1. If `isDispatchingGesture == true`, the incoming `(x, y)` coordinate overwrites `pendingMoveX` and `pendingMoveY`.
2. When the current stroke triggers `onCompleted()`, the manager checks if a pending point exists.
3. If present, it dispatches the latest point immediately in a single stroke, dropping all intermediate stale points.

---

## 4. Android System Requirements & Accessibility Configuration

To enable gesture injection, the Android host app requires an `AccessibilityService`.

### 4.1 Declare in `AndroidManifest.xml`:
```xml
<service
    android:name="com.omnios.v2.host.RemoteAccessibilityService"
    android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
    android:exported="true">
    <intent-filter>
        <action android:name="android.accessibilityservice.AccessibilityService" />
    </intent-filter>
    <meta-data
        android:name="android.accessibilityservice"
        android:resource="@xml/accessibility_service_config" />
</service>
```

### 4.2 Configuration Resource (`res/xml/accessibility_service_config.xml`):
```xml
<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes=""
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault"
    android:canPerformGestures="true"
    android:canRetrieveWindowContent="false"
    android:description="@string/accessibility_description" />
```

### 4.3 Service Implementation (`RemoteAccessibilityService.kt`):
```kotlin
package com.omnios.v2.host

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class RemoteAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        TouchInjectionManager.activeAccessibilityService = this
    }

    override fun onDestroy() {
        super.onDestroy()
        TouchInjectionManager.activeAccessibilityService = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
```

---

## 5. Admin Touch Gate Enforcement

The host device owner has absolute power over the touch pipeline:
* When `adminConfig.touchInputEnabled == false`, `TouchInjectionManager.ingestTouch()` immediately aborts without invoking `dispatchGesture()`.
* The client web application detects the lock state and renders a persistent red notification toast:
  `Touch Input Disabled by Host Admin`.
* This prevents unauthorized or accidental touches when projecting to public displays.
