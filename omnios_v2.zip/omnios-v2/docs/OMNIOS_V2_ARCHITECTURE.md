# OmniOS v2 - Server-Authoritative Remote UI & Wireless Display Architecture
### Enterprise System Blueprint: SDUI Engine, Android Ktor Host, Low-Latency Touch Telemetry & Screen Projection

---

## 1. Executive Architecture Summary

**OmniOS v2** is a fundamental architectural evolution from the standalone, client-side web desktop of OmniOS v1. In OmniOS v2, **the browser is strictly a dumb rendering terminal**, while all business logic, window geometry calculations, sandboxed file operations, process life-cycles, and security policies execute authoritatively on the host backend—specifically designed to run inside an **Android application powered by an embedded Kotlin/Ktor server**.

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   OMNIOS V2 END-TO-END TOPOLOGY                                  │
│                                                                                                  │
│   ┌──────────────────────────────────────────────────┐   WebSocket / WSS    ┌────────────────┐   │
│   │               ANDROID HOST ENGINE                │◄────────────────────►│ SDUI WEBCLIENT │   │
│   │                                                  │  Compact 10B Touch   │ (Lightweight)  │   │
│   │  ┌────────────────────────────────────────────┐  │  Differential Deltas │                │   │
│   │  │   OmniOSHostService (Foreground Service)   │  │                      │ • DOM Renderer │   │
│   │  │   • PARTIAL_WAKE_LOCK & Low-Latency WifiLock│ │                      │ • Tactile Echo │   │
│   │  │   • Thermal Pacing & Crash Shield Boundary │  │                      │ • Glass Barrier│   │
│   │  └─────────────────────┬──────────────────────┘  │                      │ • Dynamic Dock │   │
│   │                        │                         │                      └────────────────┘   │
│   │  ┌─────────────────────▼──────────────────────┐  │                                           │
│   │  │        StateEngine & Admin Controller      │  │                                           │
│   │  │   • Window Geometry & Z-Index Stack        │  │                                           │
│   │  │   • App Whitelist & Settings Visibility    │  │   H.264 Annex-B      ┌────────────────┐   │
│   │  │   • Host Storage Sandbox (SAF)             │  │◄────────────────────►│ WIRELESS CAST  │   │
│   │  └─────────────────────┬──────────────────────┘  │   Zero-Copy Stream   │ (Touch-Enabled)│   │
│   │                        │                         │  Sub-30ms Latency    │                │   │
│   │  ┌─────────────────────▼──────────────────────┐  │                      │ • WebCodecs /  │   │
│   │  │  TouchInjectionManager & DisplayProjection │  │                      │   SurfaceView  │   │
│   │  │   • Normalized Touch Ingestion (u, v)      │  │                      │ • PointerView  │   │
│   │  │   • AccessibilityService Gesture Injection │  │                      └────────────────┘   │
│   │  │   • MediaCodec H.264 Hardware Encoder      │  │                                           │
│   │  └────────────────────────────────────────────┘  │                                           │
│   └──────────────────────────────────────────────────┘                                           │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Core Pillars of the v2 Architecture

### 2.1 Server-Side Execution (Source Protection & Authority)
No application algorithms, state machines, or business logic reside on the client. When a user clicks a button, drags a window, or opens a file:
1. The client captures the pointer coordinate or button identifier and sends an event packet to the host.
2. The host `StateEngine` validates the action against the host's active `AdminConfig` whitelist.
3. The host computes the new state (e.g. window position $(x, y, w, h)$, active z-index, sandboxed directory contents).
4. The host transmits differential updates (`STATE_DELTA`) to connected clients.

### 2.2 Strict Connection Dependency & Disconnect Barrier
The client cannot operate in an offline or stale state.
* If the WebSocket connection drops, an immediate **Glass Disconnect Barrier (`#omnios-disconnect-barrier`)** engages with a backdrop blur and spinner.
* All mouse and touch inputs are instantly frozen.
* Upon network restoration, the client issues a `SYNC_REQUEST (0x22)`, receives the complete authoritative state snapshot (`FULL_SYNC (0x21)`), updates the DOM, and only then lifts the disconnect barrier.

### 2.3 Compact 10-Byte Touch Telemetry
For touch-enabled wireless displays, remote phones, or web clients, standard JSON touch strings cause bandwidth bloat and serialization overhead. OmniOS v2 utilizes an ultra-compact binary packet structure:
* **Byte 0**: Opcode (`0x01` DOWN, `0x02` MOVE, `0x03` UP, `0x04` CANCEL) — 1 byte.
* **Byte 1**: Pointer ID (`0-255`) — 1 byte.
* **Bytes 2–3**: Normalized X coordinate scaled to unsigned 16-bit integer ($0 \dots 65535$) — 2 bytes.
* **Bytes 4–5**: Normalized Y coordinate scaled to unsigned 16-bit integer ($0 \dots 65535$) — 2 bytes.
* **Bytes 6–9**: Client Timestamp in milliseconds — 4 bytes.
* **Total Packet Size**: Exactly **10 bytes**.
At 60 frames per second, this consumes merely **600 bytes/sec** per touch pointer, eliminating network congestion and providing sub-10ms touch response.

### 2.4 Immediate Local Tactile Echo
When streaming to a wireless display or web client over Wi-Fi, round-trip latency can introduce visual hesitation. To solve this, the client's `TouchController`:
* Renders an instant, hardware-accelerated ripple echo directly under the user's finger.
* Dispatches the 10-byte binary packet simultaneously.
* The user perceives instantaneous local tactile confirmation while the host processes the interaction.

### 2.5 Admin Host Authority & Touch Gating
The device hosting the operating system maintains absolute sovereignty:
* **Touch Gating**: The Admin can toggle touch input on or off via the host Android UI. When disabled, the host drops all incoming touch telemetry, and the client displays a persistent "Touch Input Disabled by Host Admin" HUD banner.
* **App Whitelisting**: Admin can selectively enable or disable any application (Files, Video Player, Audio Player, PDF Reader, Notes, Terminal, System Monitor, Settings). Disabled apps are completely pruned from the client's Dock and Desktop.
* **Settings Visibility Control**: The host dictates which tabs in the client Settings window are visible to the user.

---

## 3. Directory Structure of OmniOS v2

```
omnios-v2/
├── client/                     # Lightweight SDUI WebClient
│   ├── index.html              # Shell containing disconnect barrier & touch plane
│   ├── css/                    # Modular styling (core, apps, themes, sdui-extra)
│   ├── js/
│   │   ├── protocol.js         # Isomorphic compact packet encoder/decoder
│   │   ├── touch-controller.js # Multi-touch capture, normalization & ripple feedback
│   │   ├── sdui-client.js      # WebSocket manager, reconciler, & dynamic app renderer
│   │   ├── icons.js            # SVG vector icon pack (macOS, Windows, Linux, Android)
│   │   └── themes.js           # Visual themes & styling engine
│   └── assets/                 # Wallpapers, fonts, and local assets
│
├── server/                     # Reference Backend & Termux Runner
│   ├── server.js               # Zero-dependency HTTP + RFC 6455 WebSocket engine
│   ├── state-engine.js         # Authoritative state engine, windows & sandboxing
│   ├── admin-api.js            # REST control endpoints for host admin
│   └── protocol.js             # Server-side isomorphic protocol module
│
├── android/                    # Android Host Kotlin Subsystems
│   └── src/main/kotlin/com/omnios/v2/host/
│       ├── OmniOSHostService.kt        # Foreground service, WakeLock, anti-throttle
│       ├── KtorServer.kt               # Embedded Ktor HTTP & WSS server
│       ├── TouchInjectionManager.kt    # AccessibilityService gesture dispatcher
│       ├── AudioRoutingManager.kt      # AudioPlaybackCapture & dynamic audio routing
│       ├── AdminConfig.kt              # Configuration model & persistence
│       ├── AdminSettingsActivity.kt    # Host native UI console
│       ├── DisplayProjectionManager.kt # MediaCodec H.264 wireless casting pipeline
│       └── receiver/                   # Native App-to-App Receiver Subsystem
│           ├── ReceiverModeActivity.kt # Immersive fullscreen tablet receiver
│           ├── NativeVideoDecoder.kt   # Hardware MediaCodec SurfaceView decoder
│           ├── NativeAudioPlayer.kt    # Low-latency AudioTrack PCM player
│           └── RemoteTouchView.kt      # Touch capture & 10B binary dispatcher
│
└── docs/                       # Architectural & Subsystem Documentation
    ├── OMNIOS_V2_ARCHITECTURE.md       # Master specification (this document)
    ├── V1_VS_V2_COMPARISON.md          # Comprehensive v1 vs v2 comparison
    └── subsystems/
        ├── 01_KTOR_HOST_SERVER_ENGINE.md
        ├── 02_TOUCH_EVENT_PIPELINE.md
        ├── 03_ADMIN_CONTROL_SECURITY.md
        ├── 04_PERFORMANCE_THROTTLE_RESILIENCE.md
        ├── 05_WIRELESS_DISPLAY_PROJECTION.md
        ├── 06_APP_TO_APP_RECEIVER_MODE.md
        └── 07_AUDIO_ROUTING_AND_DISPLAY_CALIBRATION.md
```

---

## 4. End-to-End Data Flow

```mermaid
sequenceDiagram
    autonumber
    actor User as User on Touch Display / WebClient
    participant Client as SDUI WebClient (Browser)
    participant Server as Ktor / Node Host Server
    participant State as Host State Engine
    participant Android as Android Subsystems (Accessibility / MediaCodec)

    User->>Client: Tap Screen (PointerDown)
    Client->>Client: Draw immediate local ripple echo
    Client->>Server: Binary Touch Packet (10 Bytes: [0x01, id, u, v, ts])
    Server->>State: Check AdminConfig.touchInputEnabled
    alt Touch is Disabled by Admin
        State-->>Client: Broadcast Admin Policy (Touch Locked)
        Client->>Client: Display "Touch Input Disabled" HUD Toast
    else Touch is Enabled
        State->>Android: Map (u, v) -> (X, Y) & Inject via dispatchGesture()
        State->>State: Update window focus / state
        State->>Server: Emit State Delta
        Server->>Client: WebSocket STATE_DELTA [patch]
        Client->>Client: Differential DOM Reconcile & Render
    end
```
