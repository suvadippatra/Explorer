# OmniOS Architectural Comparison: v1 vs. v2
### Comprehensive Breakdown of Client-Side Architecture vs. Server-Authoritative Remote UI

---

## 1. Overview Comparison Table

| Attribute | OmniOS v1 (Client-Side OS) | OmniOS v2 (Server-Authoritative SDUI) |
| :--- | :--- | :--- |
| **Primary Execution Model** | Standalone Single-Page Application (SPA) executed entirely inside the browser. | Server-Authoritative Server-Driven UI (SDUI) hosted by an Android Kotlin/Ktor service or Node.js engine. |
| **Application Logic Location** | Browser JavaScript (`apps.js`, `wm.js`, `vfs.js`). Full business logic exposed in DevTools. | Backend Host (`StateEngine`, `TouchInjectionManager`). Browser is a lightweight rendering terminal. |
| **Window & State Management** | Client-side memory (`window.OmniOS.WindowManager`). | Authoritative host state machine. Emits differential patches (`STATE_DELTA`). |
| **Connection Dependency** | Offline-first. Operates completely without network connectivity once loaded. | Strict connection dependency. Engaging disconnect barrier (`#omnios-disconnect-barrier`) when disconnected. |
| **Touch & Wireless Casting** | Standard browser mouse/touch listeners. No projection or external touch pipeline. | Rate-independent touch telemetry (10-byte binary packets), client tactile echo, and Android gesture injection. |
| **Admin Control & Governance** | Hardcoded client settings. User has full access to all controls. | Host Admin Console. Admin controls app availability, touch permission, settings visibility, and storage sandboxing. |
| **Storage & Filesystem** | In-browser IndexedDB / Virtual File System (VFS). | Real device storage accessed via Android Storage Access Framework (SAF) and secure host sandbox. |
| **Hardware Resilience** | Browser tab lifecycle. Can be suspended by OS when backgrounded. | Android Foreground Service (`START_STICKY`) with `PARTIAL_WAKE_LOCK`, `WifiLock`, and thermal frame pacing. |
| **Proprietary Code Security** | Unprotected. Full client source accessible to any connecting browser. | Fully protected. Proprietary algorithms, file operations, and window rules reside only on the host. |

---

## 2. Structural & Runtime Differences

### 2.1 The Application Logic Split

#### In OmniOS v1:
```
[ User Action ] ──► [ Browser DOM ] ──► [ Client JS Engine (apps.js) ] ──► [ Client VFS (IndexedDB) ]
```
Every application process, file parser, and state change was calculated directly in the client browser. If a user refreshed the browser, the in-memory window layout was lost unless synced to local storage.

#### In OmniOS v2:
```
[ User Action ] ──► [ Local Tactile Echo ] ──► [ 10-Byte Binary Packet ]
                                                          │
                                                    (WebSocket)
                                                          ▼
                                            [ Android Ktor Host Engine ]
                                                          │
                                               (Validate & Compute)
                                                          ▼
[ Reconciled DOM ] ◄── (Differential Delta) ◄── [ Host StateEngine ]
```
The browser contains **zero** application logic. Clicking "Terminal" or "Video Player" simply requests the host server to open an instance. The host server allocates the window ID, computes its cascade coordinates, binds the data source, and tells the client DOM to create or patch the view element.

---

## 3. Touch Telemetry & Wireless Display Projection

### OmniOS v1:
* Bound to standard DOM event handlers (`mousemove`, `mouseup`).
* Lacks coordinate normalization or sub-pixel precision across differing display aspect ratios.
* No mechanism to inject touches into the underlying host operating system.

### OmniOS v2:
* **Coordinate Normalization**: Coordinates are normalized to $[0.0, 1.0]$ floating-point ratios ($u = x / W_{\text{client}}$, $v = y / H_{\text{client}}$).
* **Binary Telemetry**: Serialized into 10-byte typed binary packets (`[opcode, pointerId, u16X, u16Y, u32Ts]`) transmitted over WebSocket at up to 120Hz.
* **Immediate Local Echo**: Client paints an ultra-responsive visual ripple under the finger, hiding round-trip Wi-Fi transit latency.
* **Host Gesture Injection**: On the host phone, `TouchInjectionManager` translates $(u, v)$ to the phone's native resolution or headless `VirtualDisplay` and injects strokes using Android's `AccessibilityService.dispatchGesture()`.

---

## 4. Host Admin Control & Security

In OmniOS v2, the Android host app acts as the gatekeeper:

1. **Touch Gate**:
   - The device owner can disable touch input at any time.
   - Ideal when casting a presentation to a public screen or untrusted wireless display where viewing is permitted but user interaction must be blocked.
2. **App Whitelist**:
   - Admin selects which apps appear on the client dock and desktop.
   - If an unauthorized app request arrives over WebSocket, the host discards the request and issues a notification.
3. **Settings Filtering**:
   - Admin can hide sensitive configuration options (e.g., Storage, Host Diagnostics) from the client's Settings window.

---

## 5. Summary & Migration Decision

* Use **OmniOS v1** when you need a self-contained, standalone web OS that runs completely in a static browser without a backend server.
* Use **OmniOS v2** when hosting an interactive desktop from an Android phone, casting to smart TVs or wireless touch monitors, streaming hardware-accelerated media, or requiring enterprise-grade host authority and source-code protection.
