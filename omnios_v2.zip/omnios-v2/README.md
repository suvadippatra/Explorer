# OmniOS v2 - Server-Authoritative Remote UI & Wireless Display Architecture

OmniOS v2 is a next-generation Server-Driven UI (SDUI) desktop operating system engine. Unlike OmniOS v1 (which runs entirely as a client-side SPA in the browser), OmniOS v2 is designed to be hosted by an Android application (Kotlin/Ktor) or Node.js backend.

## Core Capabilities
- **Server-Authoritative SDUI**: All application execution, window geometry, sandboxing, and state logic live on the host backend.
- **4 Projection Topologies**:
  1. *Web Browser*: Zero-installation remote access via Chrome / Safari / Edge.
  2. *Wireless Display*: Cast to Miracast TVs or Wi-Fi Direct peer groups.
  3. *Wired Cable*: Zero-latency, zero-jitter wired connection over USB-C DisplayPort Alt Mode or ADB reverse tethering.
  4. *App-to-App Modality*: The same Android app runs on Phone A as Host and Tablet B as Receiver with native hardware decoding and touch injection!
- **Dynamic Audio Output Routing**: Switch audio dynamically between Host Phone Speaker, Casting Receiver Screen (Web / Tablet), or Simultaneous Dual Playback.
- **True Display Brightness & Dark Mode**: Uses real-time software luminance shading (`filter: brightness(...)` / EGL shader) so brightness actually visibly dims and brightens on any remote TV, browser, or wireless monitor.
- **Smart Fullscreen Suppression**: Automatically hides the fullscreen button on wireless displays and in native tablet receiver mode where the screen is already immersive fullscreen.
- **Ultra-Compact Touch Telemetry**: 10-byte binary packets for touch/pointer telemetry, delivering sub-10ms response over Wi-Fi.
- **Host Admin Governance**: Device owner can toggle touch events on/off, whitelist available apps, hide/show settings categories, define accessible storage directories, and upload custom icons.
- **Android Crash & Throttle Shield**: Foreground Service (`START_STICKY`), `PARTIAL_WAKE_LOCK`, `WifiLock`, and thermal frame rate pacing.

## Directory Structure
- `client/`: Lightweight SDUI WebClient (`index.html`, `js/`, `css/`, `assets/`).
- `server/`: Reference Node.js/Termux backend (`server.js`, `state-engine.js`, `admin-api.js`, `protocol.js`).
- `android/`: Production Kotlin source files:
  - Host Subsystem (`OmniOSHostService.kt`, `KtorServer.kt`, `TouchInjectionManager.kt`, `AudioRoutingManager.kt`, `AdminSettingsActivity.kt`, `DisplayProjectionManager.kt`).
  - Receiver Subsystem (`receiver/ReceiverModeActivity.kt`, `receiver/NativeVideoDecoder.kt`, `receiver/NativeAudioPlayer.kt`, `receiver/RemoteTouchView.kt`).
- `docs/`: Master architectural guide, v1 vs v2 comparison, and 7 detailed subsystem engineering blueprints (`docs/subsystems/`).

## How to Test in Termux / Node.js
```bash
# In omnios-v2 directory:
node server/server.js
```
Then open `http://localhost:8080` in your browser.

## How to Deploy on Android
See the comprehensive subsystem guides in `docs/subsystems/`.
